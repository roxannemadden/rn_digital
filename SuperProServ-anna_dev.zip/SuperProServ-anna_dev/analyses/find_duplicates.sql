/* This code outputs the duplicates of a failing uniqueness test for troubleshooting quickly */

/* variable targetModel controls which model is being tested. Enter the ref string here.     */
{% set targetModel = 'new_ga_shp_marketing_data_join_account_level' %}
/*-------------------------------------------------------------------------------------------*/

with dbt_test__target as (

  select *
  from {{ref(targetModel)}}
  where surrogate_key is not null

),

duplicates as (select
    surrogate_key,
    count(*) as n_records

from dbt_test__target
group by surrogate_key
having count(*) > 1)

select * from dbt_test__target where surrogate_key in (select distinct surrogate_key from duplicates)
order by surrogate_key



