
{{ config(materialized="table") }}

with

    marketing_data_union_mapped_patched as (
        select * from {{ ref("marketing_union_mapped_patched") }}
    ),

    ga_shp_campaign_join as (select * from {{ ref("ga_shp_campaign_join") }}),

    agg_marketing_data as (
        select
            marketing_date as m_date,
            marketing_source as marketing_source,
            m_ga_account_name,
            google_analytics_account_id as ga_mapped_account_id,
            campaign_name as m_campaign_name,
            campaign_name_geo_mapping as campaign_geo,
            Final_reporting_currency as Final_reporting_currency,
            SUM(cost) as m_cost, 
            SUM(cost_eur_conversion) AS cost_eur_conversion,
            SUM(cost_gbp_conversion) AS cost_gbp_conversion, 
            SUM(cost_usd_conversion) AS cost_usd_conversion


        from marketing_data_union_mapped_patched
        group by 1, 2, 3, 4, 5, 6, 7
    ),

    agg_ga_data as (
        select
            ga_account as mapped_ga_accountname,
            ga_account_id,
            ga_date,
            ga_source_medium,
            ga_campaign,
            SUM(item_revenue) as ga_item_revenue,
            SUM(ga_transaction_revenue) as ga_transaction_revenue,
            SUM(ga_transaction) as ga_orders,
            SUM (ga_session) as ga_session,
            SUM(shp_order_net_sales) as shopify_order_net_sales,
            SUM(shp_discounts) as shopify_discounts,
            SUM(shp_gross_sales) as shopify_gross_sales,
            SUM(shp_returns) as shopify_returns,
            SUM(shp_shipping) as shopify_shipping_costs,
            SUM(shp_sm_order_count) as shopify_orders,
            SUM(shp_tax) as shopify_tax,
            SUM(shp_total_sales) as shopify_total_sales,
            SUM(shp_gross_sales_eur_currency_conversion) AS shp_gross_sales_eur_currency_conversion,
            SUM(shp_gross_sales_gbp_currency_conversion) AS shp_gross_sales_gbp_currency_conversion,
            SUM(shp_gross_sales_usd_currency_conversion) AS shp_gross_sales_usd_currency_conversion,
            SUM(shp_net_sales_eur_currency_conversion) AS shp_net_sales_eur_currency_conversion,
            SUM(shp_net_sales_gbp_currency_conversion) AS shp_net_sales_gbp_currency_conversion,
            SUM(shp_net_sales_usd_currency_conversion) AS shp_net_sales_usd_currency_conversion,
            SUM(shp_total_sales_eur_currency_conversion) AS shp_total_sales_eur_currency_conversion,
            SUM(shp_total_sales_gbp_currency_conversion) AS shp_total_sales_gbp_currency_conversion,
            SUM(shp_total_sales_usd_currency_conversion) AS shp_total_sales_usd_currency_conversion

        from ga_shp_campaign_join

        group by 1, 2, 3, 4, 5
    ),

    joined_table as (
        select
            COALESCE(m_date, ga_date) as master_date,
            COALESCE(mapped_ga_accountname, m_ga_account_name) as master_accountname,
            COALESCE(marketing_source, ga_source_medium) as master_source_medium,
            COALESCE(m_campaign_name, ga_campaign) as master_campaign_name,
            ga_mapped_account_id,
            -- marketing_source,
            -- m_date,
            -- ga_date,
            -- m_campaign_name,
            campaign_geo,
            -- ga_source_medium,
            -- ga_campaign,
            Final_reporting_currency,
            m_cost,
            cost_eur_conversion,
            cost_gbp_conversion, 
            cost_usd_conversion,
            ga_item_revenue,
            ga_transaction_revenue,
            ga_orders,
            ga_session,
            shopify_order_net_sales,
            shopify_discounts,
            shopify_gross_sales,
            shopify_returns,
            shopify_shipping_costs,
            shopify_orders,
            shopify_tax,
            shopify_total_sales,
            shp_gross_sales_eur_currency_conversion, 
            shp_gross_sales_gbp_currency_conversion,
            shp_gross_sales_usd_currency_conversion,
            shp_net_sales_eur_currency_conversion,
            shp_net_sales_gbp_currency_conversion,
            shp_net_sales_usd_currency_conversion,
            shp_total_sales_eur_currency_conversion,
            shp_total_sales_gbp_currency_conversion,
            shp_total_sales_usd_currency_conversion

        from agg_marketing_data
        full outer join
            agg_ga_data

            on agg_marketing_data.m_campaign_name = agg_ga_data.ga_campaign
            and agg_marketing_data.m_date = agg_ga_data.ga_date
            and agg_marketing_data.ga_mapped_account_id = agg_ga_data.ga_account_id
            and agg_marketing_data.marketing_source = agg_ga_data.ga_source_medium

        order by m_date desc
    )

select
    *,

    case
        when master_source_medium like '%google / cpc%'
        then 'paid'
        when master_source_medium like 'google'
        then 'paid'
        when master_source_medium like '%criteo%'
        then 'paid'
        when master_source_medium like '%bing / cpc%'
        then 'paid'
        when master_source_medium like 'bing'
        then 'paid'
        when master_source_medium like '%facebook / cpc%'
        then 'paid'
        when master_source_medium like 'facebook'
        then 'paid'
        when master_source_medium like 'FacebookAds'
        then 'paid'
        when master_source_medium like 'tiktok'
        then 'paid'
        when master_source_medium like 'stackadapt'
        then 'paid'
        when master_source_medium like 'pinterest'
        then 'paid'
        when master_source_medium like 'snapchat'
        then 'paid'
        when master_source_medium like '%referral%'
        then 'referral'
        when master_source_medium like '%Referral%'
        then 'referral'
        when master_source_medium like '%organic%'
        then 'organic'
        when master_source_medium like '%social%'
        then 'social'
        when master_source_medium like '%Social%'
        then 'social'
        when master_source_medium like '%email%'
        then 'email'
        when master_source_medium like '%(direct) / (none)%'
        then 'direct'
        else 'other'
    end as new_source_grouping,
    {{
        dbt_utils.surrogate_key(
            [
                "master_date",
                "master_accountname",
                "ga_mapped_account_id",
                "master_source_medium",
                "master_campaign_name",
                "campaign_geo"
            ]
        )
    }} as surrogate_key

from joined_table
where master_accountname is not null
