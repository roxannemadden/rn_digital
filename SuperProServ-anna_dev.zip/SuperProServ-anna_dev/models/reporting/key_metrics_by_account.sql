{{ config(materialized="table") }}

        SELECT 
        master_date,
        master_ga_accountname,
        sum(m_cost) as cost,
        sum(ga_item_revenue) as ga_item_revenue,
        sum(ga_session) as ga_session,
        sum(ga_transaction_revenue) as ga_transaction_revenue,
        sum(ga_transaction) as ga_transaction,
        sum(order_net_sales) as order_net_sales,
        sum(shp_gross_sales) as shp_gross_sales,
        sum(shp_net_sales) as shp_net_sales,
        sum(shp_sm_order_count) as shp_sm_order_count,
        sum(shp_total_sales) as shp_total_sales
        
        FROM {{ ref('new_ga_shp_marketing_data_join_account_level') }}  
       
        GROUP BY
        master_date,
        master_ga_accountname
