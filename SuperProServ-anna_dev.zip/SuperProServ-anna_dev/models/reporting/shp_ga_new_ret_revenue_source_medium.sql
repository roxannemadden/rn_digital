{{ config(materialized="table") }}

WITH 

-- Source tables 

_shopify_ga_data AS (SELECT * FROM {{ ref('ga_shp_transaction_join') }}),
_marketing_data AS (SELECT * FROM {{ ref('marketing_union_mapped_patched_account_level') }}),

_shopify_ga_pivot AS 

    (SELECT 
        ga_date, 
        ga_account, 
        ga_account_id,
        ga_source_medium,
        SUM(ga_transaction_revenue) AS ga_transaction_revenue, 
        SUM(ga_transaction) AS ga_transaction, 
        SUM(shp_gross_sales) AS shp_gross_sales,
        SUM(shp_net_sales) AS shp_net_sales, 
        SUM(shp_sm_order_count) AS order_count, 
        SUM(shp_total_sales) AS shp_total_sales,
        SUM(shp_gross_sales_eur_currency_conversion) AS shp_gross_sales_eur_currency_conversion,
        SUM(shp_gross_sales_gbp_currency_conversion) AS shp_gross_sales_gbp_currency_conversion,
        SUM(shp_gross_sales_usd_currency_conversion) AS shp_gross_sales_usd_currency_conversion,
        SUM(shp_net_sales_eur_currency_conversion) AS shp_net_sales_eur_currency_conversion,
        SUM(shp_net_sales_gbp_currency_conversion) AS shp_net_sales_gbp_currency_conversion,
        SUM(shp_net_sales_usd_currency_conversion) AS shp_net_sales_usd_currency_conversion,
        SUM(shp_total_sales_eur_currency_conversion) AS shp_total_sales_eur_currency_conversion,
        SUM(shp_total_sales_gbp_currency_conversion) AS shp_total_sales_gbp_currency_conversion,
        SUM(shp_total_sales_usd_currency_conversion) AS shp_total_sales_usd_currency_conversion,        

        /* Original amount and currency conversion for new/returning gross sales */

	    SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_gross_sales ELSE NULL END) AS new_shp_gross_sales,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_gross_sales ELSE NULL END) AS ret_shp_gross_sales,

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_gross_sales_eur_currency_conversion ELSE NULL END) AS new_shp_gross_sales_eur_currency_conversion,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_gross_sales_eur_currency_conversion ELSE NULL END) AS ret_shp_gross_sales_eur_currency_conversion,

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_gross_sales_gbp_currency_conversion ELSE NULL END) AS new_shp_gross_sales_gbp_currency_conversion,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_gross_sales_gbp_currency_conversion ELSE NULL END) AS ret_shp_gross_sales_gbp_currency_conversion,

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_gross_sales_usd_currency_conversion ELSE NULL END) AS new_shp_gross_sales_usd_currency_conversion,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_gross_sales_usd_currency_conversion ELSE NULL END) AS ret_shp_gross_sales_usd_currency_conversion,

        /* Original amount and currency conversion for new/returning net sales */
    
        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_net_sales ELSE NULL END) AS new_shp_net_sales,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_net_sales ELSE NULL END) AS ret_shp_net_sales,

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_net_sales_eur_currency_conversion ELSE NULL END) AS new_shp_net_sales_eur_currency_conversion,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_net_sales_eur_currency_conversion ELSE NULL END) AS ret_shp_net_sales_eur_currency_conversion,

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_net_sales_gbp_currency_conversion ELSE NULL END) AS new_shp_net_sales_gbp_currency_conversion,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_net_sales_gbp_currency_conversion ELSE NULL END) AS ret_shp_net_sales_gbp_currency_conversion,

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_net_sales_usd_currency_conversion ELSE NULL END) AS new_shp_net_sales_usd_currency_conversion,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_net_sales_usd_currency_conversion ELSE NULL END) AS ret_shp_net_sales_usd_currency_conversion,

        /* Original amount and currency conversion for new/returning total sales */

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_total_sales ELSE NULL END) AS new_shp_total_sales,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_total_sales ELSE NULL END) AS ret_shp_total_sales,

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_total_sales_eur_currency_conversion ELSE NULL END) AS new_shp_total_sales_eur_currency_conversion,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_total_sales_eur_currency_conversion ELSE NULL END) AS ret_shp_total_sales_eur_currency_conversion,

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_total_sales_gbp_currency_conversion ELSE NULL END) AS new_shp_total_sales_gbp_currency_conversion,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_total_sales_gbp_currency_conversion ELSE NULL END) AS ret_shp_total_sales_gbp_currency_conversion,

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_total_sales_usd_currency_conversion ELSE NULL END) AS new_shp_total_sales_usd_currency_conversion,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_total_sales_usd_currency_conversion ELSE NULL END) AS ret_shp_total_sales_usd_currency_conversion,

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_sm_order_count ELSE NULL END) AS new_order_count,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_sm_order_count ELSE NULL END) AS ret_order_count,

    FROM _shopify_ga_data
    GROUP BY ga_date, ga_account, ga_account_id, ga_source_medium
),

_marketing_data_pivot AS 

(SELECT 
    marketing_date AS m_date, 
    marketing_source, 
    Google_Analytics_account_id, 
    master_account_name, 
    SUM(cost) AS cost,
    sum(cost_eur_conversion) AS cost_eur_conversion,
    sum(cost_gbp_conversion) AS cost_gbp_conversion, 
    sum(cost_usd_conversion) AS cost_usd_conversion

FROM _marketing_data

GROUP BY m_date, marketing_source, Google_Analytics_account_id, master_account_name
),

_marketing_shp_ga_join AS 

(SELECT 
    COALESCE(ga_date, m_date) AS date, 
    COALESCE(ga_account, master_account_name) AS master_account_name,
    COALESCE(marketing_source, ga_source_medium) AS source_medium,
    SUM(ga_transaction_revenue) AS ga_transaction_revenue, 
    SUM(ga_transaction) AS ga_transaction, 
    SUM(shp_gross_sales) AS shp_gross_sales,
    SUM(shp_net_sales) AS shp_net_sales, 
    SUM(order_count) AS order_count, 
    SUM(shp_total_sales) AS shp_total_sales,
    SUM(new_shp_gross_sales) AS new_shp_gross_sales,
	SUM(ret_shp_gross_sales) AS ret_shp_gross_sales,
    SUM(new_shp_net_sales) AS new_shp_net_sales,
    SUM(ret_shp_net_sales) AS ret_shp_net_sales,
    SUM(new_shp_total_sales) AS new_shp_total_sales,
    SUM(ret_shp_total_sales) AS ret_shp_total_sales,
    SUM(new_shp_gross_sales_eur_currency_conversion) AS new_shp_gross_sales_eur_currency_conversion,
    SUM(ret_shp_gross_sales_eur_currency_conversion) AS ret_shp_gross_sales_eur_currency_conversion,
    SUM(new_shp_gross_sales_gbp_currency_conversion) AS new_shp_gross_sales_gbp_currency_conversion,
    SUM(ret_shp_gross_sales_gbp_currency_conversion) AS ret_shp_gross_sales_gbp_currency_conversion,
    SUM(new_shp_gross_sales_usd_currency_conversion) AS new_shp_gross_sales_usd_currency_conversion,
    SUM(ret_shp_gross_sales_usd_currency_conversion) AS ret_shp_gross_sales_usd_currency_conversion,
    SUM(new_shp_net_sales_eur_currency_conversion) AS new_shp_net_sales_eur_currency_conversion,
    SUM(ret_shp_net_sales_eur_currency_conversion) AS ret_shp_net_sales_eur_currency_conversion,
    SUM(new_shp_net_sales_gbp_currency_conversion) AS new_shp_net_sales_gbp_currency_conversion,
    SUM(ret_shp_net_sales_gbp_currency_conversion) AS ret_shp_net_sales_gbp_currency_conversion,
    SUM(new_shp_net_sales_usd_currency_conversion) AS new_shp_net_sales_usd_currency_conversion,
    SUM(ret_shp_net_sales_usd_currency_conversion) AS ret_shp_net_sales_usd_currency_conversion,
    SUM(new_shp_total_sales_eur_currency_conversion) AS new_shp_total_sales_eur_currency_conversion,
    SUM(ret_shp_total_sales_eur_currency_conversion) AS ret_shp_total_sales_eur_currency_conversion,
    SUM(new_shp_total_sales_gbp_currency_conversion) AS new_shp_total_sales_gbp_currency_conversion,
    SUM(ret_shp_total_sales_gbp_currency_conversion) AS ret_shp_total_sales_gbp_currency_conversion,
    SUM(new_shp_total_sales_usd_currency_conversion) AS new_shp_total_sales_usd_currency_conversion,
    SUM(ret_shp_total_sales_usd_currency_conversion) AS ret_shp_total_sales_usd_currency_conversion,
    SUM(new_order_count) AS new_order_count,
    SUM(ret_order_count) AS ret_order_count,
    SUM(cost) AS cost,
    sum(cost_eur_conversion) AS cost_eur_conversion,
    sum(cost_gbp_conversion) AS cost_gbp_conversion, 
    sum(cost_usd_conversion) AS cost_usd_conversion

FROM _shopify_ga_pivot
    INNER JOIN _marketing_data_pivot
    on _marketing_data_pivot.m_date = _shopify_ga_pivot.ga_date
    AND _marketing_data_pivot.Google_Analytics_account_id = _shopify_ga_pivot.ga_account_id
    AND _marketing_data_pivot.marketing_source = _shopify_ga_pivot.ga_source_medium

GROUP BY date, master_account_name, source_medium

)

SELECT * FROM _marketing_shp_ga_join 
