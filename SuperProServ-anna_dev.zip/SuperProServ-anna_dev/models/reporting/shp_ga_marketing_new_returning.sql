{{ config(materialized="table") }}

with 

_shopify_data AS (SELECT * FROM {{ ref('shp_ga_mapping') }} ), 
_ga_data AS (SELECT * FROM {{ ref('ga_data_account_level_sessions_join') }} ), 
_marketing_data AS (SELECT * FROM {{ ref('marketing_union_mapped_patched_account_level') }}),


_shopify_sales_data AS (
    SELECT
        transaction_date as date,
        Google_Analytics_account_id,
        shp_order_is_returning_customer,
        SUM(shp_gross_sales) AS shp_gross_sales,
        SUM(shp_net_sales) AS shp_net_sales,
        SUM(shp_sm_order_count) AS shp_sm_order_count,
        SUM(shp_total_sales) AS shp_total_sales

    FROM _shopify_data
    GROUP BY 1, 2, 3
),

_new_shp_orders AS (
    SELECT
        date,
        Google_Analytics_account_id,
        SUM(shp_net_sales) AS new_shp_net_sales,
        SUM(shp_gross_sales) AS new_shp_gross_sales,
        SUM(shp_total_sales) AS new_shp_total_sales,
        SUM(shp_sm_order_count) AS new_shp_orders,
    FROM _shopify_sales_data
    WHERE shp_order_is_returning_customer IS NOT TRUE
    GROUP BY 1, 2
    ),

_ret_shp_orders AS (
    SELECT
        date,
        Google_Analytics_account_id,
        SUM(shp_net_sales) AS ret_shp_net_sales,
        SUM(shp_gross_sales) AS ret_shp_gross_sales,
        SUM(shp_total_sales) AS ret_shp_total_sales,
        SUM(shp_sm_order_count) AS ret_shp_orders,
    FROM _shopify_sales_data
    WHERE shp_order_is_returning_customer IS TRUE
    GROUP BY 1, 2
    ),

    
_shopify_pivot AS (
    SELECT 
        COALESCE(_new_shp_orders.date, _ret_shp_orders.date) AS date,
        COALESCE(_new_shp_orders.Google_Analytics_account_id, _ret_shp_orders.Google_Analytics_account_id) AS Google_Analytics_account_id,
        SUM(new_shp_orders) AS new_shp_orders,
        SUM(new_shp_net_sales) AS new_shp_net_sales,
        SUM(new_shp_gross_sales) AS new_shp_gross_sales,
        SUM(new_shp_total_sales) AS new_shp_total_sales,
        SUM(ret_shp_orders) AS ret_shp_orders,
        SUM(ret_shp_net_sales) AS ret_shp_net_sales, 
        SUM(ret_shp_gross_sales) AS ret_shp_gross_sales,
        SUM(ret_shp_total_sales) AS ret_shp_total_sales,

    FROM _new_shp_orders
    FULL JOIN _ret_shp_orders
    on _new_shp_orders.date = _ret_shp_orders.date
    AND _new_shp_orders.Google_Analytics_account_id = _ret_shp_orders.Google_Analytics_account_id
    GROUP BY 1, 2

), 

_ga_transaction_data AS (
    SELECT
        ga_date as date,
        ga_account_id,
        mapped_ga_accountname, 
        SUM(ga_transaction_revenue) as ga_transaction_revenue,
        SUM(ga_transaction) as ga_transaction,
    FROM _ga_data
    WHERE mapped_ga_accountname IS NOT NULL
    GROUP BY 1, 2, 3 
),

_marketing_cost_data AS (
    SELECT
        marketing_date as date,
        Google_Analytics_account_id,
        master_account_name,
        SUM(cost) AS cost,
        SUM(cost_eur_conversion) AS cost_eur_conversion,
        SUM(cost_gbp_conversion) AS cost_gbp_conversion, 
        SUM(cost_usd_conversion) AS cost_usd_conversion
    FROM _marketing_data
    GROUP BY 1, 2, 3
),

transaction_cost_join AS (
    SELECT 
        COALESCE(master_account_name, mapped_ga_accountname) AS account_name,
        COALESCE(_marketing_cost_data.date, _ga_transaction_data.date, _shopify_pivot.date) AS date,
        SUM(cost) AS cost, 
        SUM(cost_eur_conversion) AS cost_eur_conversion,
        SUM(cost_gbp_conversion) AS cost_gbp_conversion, 
        SUM(cost_usd_conversion) AS cost_usd_conversion,
        SUM(ga_transaction_revenue) AS ga_transaction_revenue, 
        SUM(ga_transaction) AS ga_transaction, 
        SUM(new_shp_orders) AS new_shp_orders,
        SUM(new_shp_net_sales) AS new_shp_net_sales,
        SUM(new_shp_gross_sales) AS new_shp_gross_sales,
        SUM(new_shp_total_sales) AS new_shp_total_sales,
        SUM(ret_shp_orders) AS ret_shp_orders,
        SUM(ret_shp_net_sales) AS ret_shp_net_sales, 
        SUM(ret_shp_gross_sales) AS ret_shp_gross_sales,
        SUM(ret_shp_total_sales) AS ret_shp_total_sales

    FROM _marketing_cost_data
    FULL JOIN _ga_transaction_data
    on _marketing_cost_data.date = _ga_transaction_data.date
    AND _marketing_cost_data.Google_Analytics_account_id = _ga_transaction_data.ga_account_id
    FULL JOIN _shopify_pivot
    on _ga_transaction_data.date = _shopify_pivot.date
    AND _ga_transaction_data.ga_account_id = _shopify_pivot.Google_Analytics_account_id
    

    GROUP BY 1, 2)


SELECT * FROM transaction_cost_join




