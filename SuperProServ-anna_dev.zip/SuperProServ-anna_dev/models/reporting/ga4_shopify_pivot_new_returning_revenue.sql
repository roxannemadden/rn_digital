{{ config(materialized="table") }}

WITH 

-- Source tables 

_shopify_ga4_data AS (SELECT * FROM {{ ref('ga4_shp_transaction_join') }}),
_marketing_data AS (SELECT * FROM {{ ref('marketing_union_mapped_patched_account_level') }}),

_shopify_ga4_pivot AS 

(SELECT 
        ga4_date,       
        Client,
        ga4_source_medium,
        ga4_account_id,
        shp_order_is_returning_customer,
        SUM(purchaserevenue) AS purchaserevenue, 
        SUM(transactions) AS transactions,
        SUM(shp_discounts) AS shp_discounts, 
        SUM(shp_gross_sales) AS shp_gross_sales,
        SUM(shp_net_sales) AS shp_net_sales, 
        SUM(shp_total_sales) AS shp_total_sales,
        SUM(shp_returns) AS shp_returns,
        SUM(shp_shipping) AS shp_shipping,
        SUM(shp_sm_order_count) AS shp_sm_order_count,
        SUM(shp_tax) AS shp_tax,
        SUM(shp_gross_sales_eur_currency_conversion) AS shp_gross_sales_eur_currency_conversion,
        SUM(shp_gross_sales_gbp_currency_conversion) AS shp_gross_sales_gbp_currency_conversion,
        SUM(shp_gross_sales_usd_currency_conversion) AS shp_gross_sales_usd_currency_conversion,
        SUM(shp_net_sales_eur_currency_conversion) AS shp_net_sales_eur_currency_conversion,
        SUM(shp_net_sales_gbp_currency_conversion) AS shp_net_sales_gbp_currency_conversion,
        SUM(shp_net_sales_usd_currency_conversion) AS shp_net_sales_usd_currency_conversion,
        SUM(shp_total_sales_eur_currency_conversion) AS shp_total_sales_eur_currency_conversion,
        SUM(shp_total_sales_gbp_currency_conversion) AS shp_total_sales_gbp_currency_conversion,
        SUM(shp_total_sales_usd_currency_conversion) AS shp_total_sales_usd_currency_conversion,

        /* Original amount and currency conversion for new/returning gross sales */

	    SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_gross_sales ELSE NULL END) AS new_shp_gross_sales,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_gross_sales ELSE NULL END) AS ret_shp_gross_sales,

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_gross_sales_eur_currency_conversion ELSE NULL END) AS new_shp_gross_sales_eur_currency_conversion,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_gross_sales_eur_currency_conversion ELSE NULL END) AS ret_shp_gross_sales_eur_currency_conversion,

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_gross_sales_gbp_currency_conversion ELSE NULL END) AS new_shp_gross_sales_gbp_currency_conversion,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_gross_sales_gbp_currency_conversion ELSE NULL END) AS ret_shp_gross_sales_gbp_currency_conversion,

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_gross_sales_usd_currency_conversion ELSE NULL END) AS new_shp_gross_sales_usd_currency_conversion,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_gross_sales_usd_currency_conversion ELSE NULL END) AS ret_shp_gross_sales_usd_currency_conversion,

        /* Original amount and currency conversion for new/returning net sales */
    
        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_net_sales ELSE NULL END) AS new_shp_net_sales,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_net_sales ELSE NULL END) AS ret_shp_net_sales,

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_net_sales_eur_currency_conversion ELSE NULL END) AS new_shp_net_sales_eur_currency_conversion,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_net_sales_eur_currency_conversion ELSE NULL END) AS ret_shp_net_sales_eur_currency_conversion,

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_net_sales_gbp_currency_conversion ELSE NULL END) AS new_shp_net_sales_gbp_currency_conversion,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_net_sales_gbp_currency_conversion ELSE NULL END) AS ret_shp_net_sales_gbp_currency_conversion,

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_net_sales_usd_currency_conversion ELSE NULL END) AS new_shp_net_sales_usd_currency_conversion,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_net_sales_usd_currency_conversion ELSE NULL END) AS ret_shp_net_sales_usd_currency_conversion,

        /* Original amount and currency conversion for new/returning total sales */

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_total_sales ELSE NULL END) AS new_shp_total_sales,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_total_sales ELSE NULL END) AS ret_shp_total_sales,

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_total_sales_eur_currency_conversion ELSE NULL END) AS new_shp_total_sales_eur_currency_conversion,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_total_sales_eur_currency_conversion ELSE NULL END) AS ret_shp_total_sales_eur_currency_conversion,

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_total_sales_gbp_currency_conversion ELSE NULL END) AS new_shp_total_sales_gbp_currency_conversion,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_total_sales_gbp_currency_conversion ELSE NULL END) AS ret_shp_total_sales_gbp_currency_conversion,

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_total_sales_usd_currency_conversion ELSE NULL END) AS new_shp_total_sales_usd_currency_conversion,
	    SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_total_sales_usd_currency_conversion ELSE NULL END) AS ret_shp_total_sales_usd_currency_conversion,
    
        /* GA4 revenue metrics pivoted to new/returning revenue */

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN purchaserevenue ELSE NULL END) AS new_ga4_purchaserevenue,
        SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN purchaserevenue ELSE NULL END) AS ret_ga4_purchaserevenue, 

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN transactions ELSE NULL END) AS new_ga4_transactions,
        SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN transactions ELSE NULL END) AS ret_ga4_transactions,

        SUM(CASE WHEN shp_order_is_returning_customer IS NULL THEN shp_sm_order_count ELSE NULL END) AS new_order_count,
        SUM(CASE WHEN shp_order_is_returning_customer IS NOT NULL THEN shp_sm_order_count ELSE NULL END) AS ret_order_count   


FROM _shopify_ga4_data

GROUP BY 
    ga4_date,       
    Client, 
    ga4_source_medium,
    ga4_account_id,
    shp_order_is_returning_customer
),

_marketing_data_pivot AS 

(SELECT 
    marketing_date AS m_date, 
    marketing_source, 
    Google_Analytics_account_id, 
    master_account_name, 
    SUM(cost) AS cost,
    sum(cost_eur_conversion) AS cost_eur_conversion,
    sum(cost_gbp_conversion) AS cost_gbp_conversion, 
    sum(cost_usd_conversion) AS cost_usd_conversion

FROM _marketing_data

GROUP BY m_date, marketing_source, Google_Analytics_account_id, master_account_name
),

_marketing_shp_ga_join AS 

(SELECT 
    COALESCE(m_date, ga4_date) AS date, 
    COALESCE(master_account_name, Client) AS master_account_name,
    COALESCE(marketing_source, ga4_source_medium) AS source_medium,
    SUM(purchaserevenue) AS purchaserevenue, 
    SUM(transactions) AS transactions, 
    SUM(shp_gross_sales) AS shp_gross_sales,
    SUM(shp_net_sales) AS shp_net_sales, 
    SUM(shp_sm_order_count) AS shp_sm_order_count, 
    SUM(shp_total_sales) AS shp_total_sales,
    SUM(new_shp_gross_sales) AS new_shp_gross_sales,
	SUM(ret_shp_gross_sales) AS ret_shp_gross_sales,
    SUM(new_shp_net_sales) AS new_shp_net_sales,
    SUM(ret_shp_net_sales) AS ret_shp_net_sales,
    SUM(new_shp_total_sales) AS new_shp_total_sales,
    SUM(ret_shp_total_sales) AS ret_shp_total_sales,
    SUM(new_order_count) AS new_order_count,
    SUM(ret_order_count) AS ret_order_count,
    SUM(new_ga4_purchaserevenue) AS new_ga4_purchaserevenue,
    SUM(ret_ga4_purchaserevenue) AS ret_ga4_purchaserevenue,
    SUM(cost) AS cost,
    sum(cost_eur_conversion) AS cost_eur_conversion,
    sum(cost_gbp_conversion) AS cost_gbp_conversion, 
    sum(cost_usd_conversion) AS cost_usd_conversion, 
    SUM(new_shp_gross_sales_eur_currency_conversion) AS new_shp_gross_sales_eur_currency_conversion,
    SUM(ret_shp_gross_sales_eur_currency_conversion) AS ret_shp_gross_sales_eur_currency_conversion,
    SUM(new_shp_gross_sales_gbp_currency_conversion) AS new_shp_gross_sales_gbp_currency_conversion,
    SUM(ret_shp_gross_sales_gbp_currency_conversion) AS ret_shp_gross_sales_gbp_currency_conversion,
    SUM(new_shp_gross_sales_usd_currency_conversion) AS new_shp_gross_sales_usd_currency_conversion,
    SUM(ret_shp_gross_sales_usd_currency_conversion) AS ret_shp_gross_sales_usd_currency_conversion,
    SUM(new_shp_net_sales_eur_currency_conversion) AS new_shp_net_sales_eur_currency_conversion,
    SUM(ret_shp_net_sales_eur_currency_conversion) AS ret_shp_net_sales_eur_currency_conversion,
    SUM(new_shp_net_sales_gbp_currency_conversion) AS new_shp_net_sales_gbp_currency_conversion,
    SUM(ret_shp_net_sales_gbp_currency_conversion) AS ret_shp_net_sales_gbp_currency_conversion,
    SUM(new_shp_net_sales_usd_currency_conversion) AS new_shp_net_sales_usd_currency_conversion,
    SUM(ret_shp_net_sales_usd_currency_conversion) AS ret_shp_net_sales_usd_currency_conversion,
    SUM(new_shp_total_sales_eur_currency_conversion) AS new_shp_total_sales_eur_currency_conversion,
    SUM(ret_shp_total_sales_eur_currency_conversion) AS ret_shp_total_sales_eur_currency_conversion,
    SUM(new_shp_total_sales_gbp_currency_conversion) AS new_shp_total_sales_gbp_currency_conversion,
    SUM(ret_shp_total_sales_gbp_currency_conversion) AS ret_shp_total_sales_gbp_currency_conversion,
    SUM(new_shp_total_sales_usd_currency_conversion) AS new_shp_total_sales_usd_currency_conversion,
    SUM(ret_shp_total_sales_usd_currency_conversion) AS ret_shp_total_sales_usd_currency_conversion, 
    SUM(shp_gross_sales_eur_currency_conversion) AS shp_gross_sales_eur_currency_conversion,
    SUM(shp_gross_sales_gbp_currency_conversion) AS shp_gross_sales_gbp_currency_conversion,
    SUM(shp_gross_sales_usd_currency_conversion) AS shp_gross_sales_usd_currency_conversion,
    SUM(shp_net_sales_eur_currency_conversion) AS shp_net_sales_eur_currency_conversion,
    SUM(shp_net_sales_gbp_currency_conversion) AS shp_net_sales_gbp_currency_conversion,
    SUM(shp_net_sales_usd_currency_conversion) AS shp_net_sales_usd_currency_conversion,
    SUM(shp_total_sales_eur_currency_conversion) AS shp_total_sales_eur_currency_conversion,
    SUM(shp_total_sales_gbp_currency_conversion) AS shp_total_sales_gbp_currency_conversion,
    SUM(shp_total_sales_usd_currency_conversion) AS shp_total_sales_usd_currency_conversion

FROM _shopify_ga4_pivot
    FULL OUTER JOIN _marketing_data_pivot
    on _marketing_data_pivot.m_date = _shopify_ga4_pivot.ga4_date
    AND _marketing_data_pivot.Google_Analytics_account_id = _shopify_ga4_pivot.ga4_account_id
    AND _marketing_data_pivot.marketing_source = _shopify_ga4_pivot.ga4_source_medium

GROUP BY date, master_account_name, source_medium

),

    _fields as (
        select
            *,
            case
                when source_medium like 'google'
                then 'Google Paid'
                when source_medium like 'criteo'
                then 'Criteo'
                when source_medium like 'bing'
                then 'Microsoft Paid'
                when source_medium like 'facebook'
                then 'Meta Paid'
                when source_medium like 'FacebookAds'
                then 'Meta Paid'
                when source_medium like 'pinterest'
                then 'Pinterest'
                when source_medium like 'stackadapt'
                then 'Stackadapt Paid'
                when source_medium like 'snapchat'
                then 'Snapchat Paid'
                when source_medium like '%referral%'
                then 'referral'
                when source_medium like '%Referral%'
                then 'referral'
                when source_medium like '%organic%'
                then 'organic'
                when source_medium like '%social%'
                then 'social'
                when source_medium like '%Social%'
                then 'social'
                when source_medium like '%email%'
                then 'email'
                when source_medium like 'tiktok'
                then 'TikTok Paid'
                when source_medium like '%(direct) / (none)%'
                then 'direct'
                when source_medium like 'affiliate'
                then 'Affiliate'
                when source_medium like 'shareasale'
                then 'Affiliate'
                when source_medium like 'shopstyle'
                then 'Affiliate'
                when source_medium like 'lyst'
                then 'Affiliate'
                when source_medium like 'linkby'
                then 'Affiliate'
                when source_medium like 'awin'
                then 'Affiliate'
                else 'other'
            end as new_source_grouping
        FROM _marketing_shp_ga_join),

_surrogate_key AS 
    (SELECT *, 
        {{dbt_utils.surrogate_key([
        'date',
        'master_account_name',
        'source_medium'
    ])
 }} as surrogate_key
    FROM _fields)

select *
from _surrogate_key
