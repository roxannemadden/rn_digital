{{ config(materialized="table") }}

WITH 

marketing_union_GA4_mapping as (
  SELECT * FROM {{ ref('marketing_union_GA4_mapping') }}

),

ga4_source_unique_id AS (
  SELECT * FROM {{ ref('ga4_source_unique_id') }}

),

_agg_marketing_data AS (
    SELECT
      date, 
      marketing_source, 
      Google_Analytics_4_id, 
      Client, 
      campaign_name,
      SUM(cost) AS cost, 
      SUM(cost_eur_conversion) AS cost_eur_conversion,
      SUM(cost_gbp_conversion) AS cost_gbp_conversion, 
      SUM(cost_usd_conversion) AS cost_usd_conversion

    FROM marketing_union_GA4_mapping
    GROUP BY date, Client, Google_Analytics_4_id, marketing_source, campaign_name

),

_agg_ga4_data AS (
    SELECT
      ga4_date, 
      new_source,
      ga4_profile_id,
      ga4_profile,
      ga4_campaign_name,
      SUM(purchaseRevenue) AS purchase_revenue,
      SUM(transactions) AS transactions, 
      SUM(ga4_eur_gbp_converted_revenue) AS ga4_eur_gbp_converted_revenue,
      SUM(ga4_eur_usd_converted_revenue) AS ga4_eur_usd_converted_revenue, 
      SUM(ga4_gbp_eur_converted_revenue) AS ga4_gbp_eur_converted_revenue, 
      SUM(ga4_gbp_usd_converted_revenue) AS ga4_gbp_usd_converted_revenue, 
      SUM(ga4_usd_eur_converted_revenue) AS ga4_usd_eur_converted_revenue, 
      SUM(ga4_usd_gbp_converted_revenue) AS ga4_usd_gbp_converted_revenue,
      

    FROM ga4_source_unique_id
    GROUP BY ga4_date, ga4_profile, ga4_profile_id, new_source, ga4_campaign_name
  
),


_join AS ( 
  
  SELECT 
    coalesce(Client, ga4_profile) as master_account_name,
    coalesce(date, ga4_date) as master_date,
    coalesce(new_source, marketing_source) as master_source,
    coalesce(campaign_name, ga4_campaign_name) as master_campaign_name,
    cost,
    cost_eur_conversion,
    cost_gbp_conversion, 
    cost_usd_conversion, 
    purchase_revenue,
    transactions,
    ga4_eur_gbp_converted_revenue,
    ga4_eur_usd_converted_revenue, 
    ga4_gbp_eur_converted_revenue, 
    ga4_gbp_usd_converted_revenue, 
    ga4_usd_eur_converted_revenue, 
    ga4_usd_gbp_converted_revenue

  FROM _agg_marketing_data AS marketing_data
  FULL OUTER JOIN _agg_ga4_data as ga4_data

    ON marketing_data.date = ga4_data.ga4_date
    and marketing_data.marketing_source = ga4_data.new_source
    and marketing_data.Google_Analytics_4_id = ga4_data.ga4_profile_id
    and marketing_data.campaign_name = ga4_data.ga4_campaign_name

),

_agg_join AS (

    SELECT
        master_date,
        master_account_name,
        master_source,
        master_campaign_name,
        SUM(cost) AS cost,
        SUM(cost_eur_conversion) AS cost_eur_conversion,
        SUM(cost_gbp_conversion) AS cost_gbp_conversion, 
        SUM(cost_usd_conversion) AS cost_usd_conversion,  
        SUM(purchase_revenue) AS purchase_revenue,
        SUM(transactions) AS transactions,
        SUM(ga4_eur_gbp_converted_revenue) AS ga4_eur_gbp_converted_revenue,
        SUM(ga4_eur_usd_converted_revenue) AS ga4_eur_usd_converted_revenue, 
        SUM(ga4_gbp_eur_converted_revenue) AS ga4_gbp_eur_converted_revenue, 
        SUM(ga4_gbp_usd_converted_revenue) AS ga4_gbp_usd_converted_revenue, 
        SUM(ga4_usd_eur_converted_revenue) AS ga4_usd_eur_converted_revenue, 
        SUM(ga4_usd_gbp_converted_revenue) AS ga4_usd_gbp_converted_revenue


    FROM _join
    GROUP BY master_date, master_account_name, master_source, master_campaign_name
),

_fields AS (
SELECT 
*, 
    case
    when master_source like 'google' then 'paid'
    when master_source like 'criteo' then 'paid'
    when master_source like 'bing' then 'paid'
    when master_source like 'facebook' then 'paid'
    when master_source like 'FacebookAds' then 'paid'
    when master_source like 'pinterest' then 'paid'
    when master_source like 'stackadapt' then 'paid'
    when master_source like 'snapchat' then 'paid'
    when master_source like '%referral%' then 'referral'
    when master_source like '%Referral%' then 'referral'
    when master_source like '%organic%' then 'organic'
    when master_source like '%social%' then 'social'
    when master_source like '%Social%' then 'social'
    when master_source like '%email%' then 'email'
    when master_source like '%(direct) / (none)%' then 'direct'
    else 'other' 
    end as source_grouping,

  {{dbt_utils.surrogate_key(
    ['master_date', 'master_account_name', 'master_source']
  )}} as surrogate_key

FROM _agg_join
)

SELECT * FROM _fields