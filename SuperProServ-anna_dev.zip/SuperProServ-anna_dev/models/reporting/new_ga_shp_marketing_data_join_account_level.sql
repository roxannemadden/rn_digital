{{ config(materialized="table") }}

with
    marketing_union_mapped_patched_account_level as (
        select * from {{ ref("marketing_union_mapped_patched_account_level") }}
    ),

    ga_shp_transaction_join_account_level as (
        select * from {{ ref("ga_shp_transaction_join_account_level") }}
    ),

    _agg_marketing_data as (
        select
            marketing_date as m_date,
            marketing_source as marketing_source,
            google_analytics_account_id as ga_mapped_account_id,
            master_account_name,
            Final_reporting_currency,
            SUM(cost) as m_cost,
            SUM(cost_eur_conversion) AS cost_eur_conversion,
            SUM(cost_gbp_conversion) AS cost_gbp_conversion, 
            SUM(cost_usd_conversion) AS cost_usd_conversion

        from marketing_union_mapped_patched_account_level
        group by 1, 2, 3, 4, 5
    ),

    _agg_ga_data as (

        select
            ga_date,
            ga_account,
            ga_account_id,
            ga_new_source_medium,
            ga_unique_id,
            mapped_ga_accountname,
            SUM(ga_item_revenue) as ga_item_revenue,
            SUM(ga_session) as ga_session,
            SUM(ga_transaction_revenue) as ga_transaction_revenue,
            SUM(ga_transaction) as ga_transaction,
            SUM(order_net_sales) as order_net_sales,
            SUM(shp_discounts) as shp_discounts,
            SUM(shp_gross_sales) as shp_gross_sales,
            SUM(shp_net_sales) as shp_net_sales,
            SUM(shp_returns) as shp_returns,
            SUM(shp_shipping) as shp_shipping,
            SUM(shp_sm_order_count) as shp_sm_order_count,
            SUM(shp_tax) as shp_tax,
            SUM(shp_total_sales) as shp_total_sales, 
            SUM(shp_gross_sales_eur_currency_conversion) AS shp_gross_sales_eur_currency_conversion,
            SUM(shp_gross_sales_gbp_currency_conversion) AS shp_gross_sales_gbp_currency_conversion,
            SUM(shp_gross_sales_usd_currency_conversion) AS shp_gross_sales_usd_currency_conversion,
            SUM(shp_net_sales_eur_currency_conversion) AS shp_net_sales_eur_currency_conversion,
            SUM(shp_net_sales_gbp_currency_conversion) AS shp_net_sales_gbp_currency_conversion,
            SUM(shp_net_sales_usd_currency_conversion) AS shp_net_sales_usd_currency_conversion,
            SUM(shp_total_sales_eur_currency_conversion) AS shp_total_sales_eur_currency_conversion,
            SUM(shp_total_sales_gbp_currency_conversion) AS shp_total_sales_gbp_currency_conversion,
            SUM(shp_total_sales_usd_currency_conversion) AS shp_total_sales_usd_currency_conversion

        from ga_shp_transaction_join_account_level
        group by 1, 2, 3, 4, 5, 6
    ),

    _joined_table as (
        select

            coalesce(m_date, ga_date) as master_date,
            coalesce(master_account_name, mapped_ga_accountname, ga_account, 'unknown') as master_ga_accountname,
            coalesce(marketing_source, ga_new_source_medium) as master_source_medium,
            -- marketing_source,
            ga_mapped_account_id,
            -- m_ga_account_name,
            -- m_unique_id,
            -- ga_account,
            ga_account_id,
            -- ga_new_source_medium,
            -- ga_unique_id,
            Final_reporting_currency,
            m_cost,
            cost_eur_conversion,
            cost_gbp_conversion, 
            cost_usd_conversion,
            ga_item_revenue,
            ga_session,
            ga_transaction_revenue,
            ga_transaction,
            order_net_sales,
            shp_discounts,
            shp_gross_sales,
            shp_net_sales,
            shp_returns,
            shp_shipping,
            shp_sm_order_count,
            shp_tax,
            shp_total_sales,
            shp_gross_sales_eur_currency_conversion, 
            shp_gross_sales_gbp_currency_conversion,
            shp_gross_sales_usd_currency_conversion,
            shp_net_sales_eur_currency_conversion,
            shp_net_sales_gbp_currency_conversion,
            shp_net_sales_usd_currency_conversion,
            shp_total_sales_eur_currency_conversion,
            shp_total_sales_gbp_currency_conversion,
            shp_total_sales_usd_currency_conversion

        from _agg_marketing_data as marketing_data
        full outer join
            _agg_ga_data as ga_data

            on marketing_data.m_date = ga_data.ga_date
            and marketing_data.master_account_name = ga_data.mapped_ga_accountname
            and marketing_data.marketing_source = ga_data.ga_new_source_medium
        order by m_date desc
    ),

    _agg_join as (
      select
        master_date,
        master_ga_accountname,
        master_source_medium,
        Final_reporting_currency as Final_reporting_currency,
        --ga_mapped_account_id,
        --ga_account_id,
        SUM(m_cost) as m_cost,
        SUM(cost_eur_conversion) AS cost_eur_conversion,
        SUM(cost_gbp_conversion) AS cost_gbp_conversion, 
        SUM(cost_usd_conversion) AS cost_usd_conversion,
        SUM(ga_item_revenue) as ga_item_revenue,
        SUM(ga_session) as ga_session,
        SUM(ga_transaction_revenue) as ga_transaction_revenue,
        SUM(ga_transaction) as ga_transaction,
        SUM(order_net_sales) as order_net_sales,
        SUM(shp_discounts) as shp_discounts,
        SUM(shp_gross_sales) as shp_gross_sales,
        SUM(shp_net_sales) as shp_net_sales,
        SUM(shp_returns) as shp_returns,
        SUM(shp_shipping) as shp_shipping,
        SUM(shp_sm_order_count) as shp_sm_order_count,
        SUM(shp_tax) as shp_tax,
        SUM(shp_total_sales) as shp_total_sales, 
        SUM(shp_gross_sales_eur_currency_conversion) AS shp_gross_sales_eur_currency_conversion,
        SUM(shp_gross_sales_gbp_currency_conversion) AS shp_gross_sales_gbp_currency_conversion,
        SUM(shp_gross_sales_usd_currency_conversion) AS shp_gross_sales_usd_currency_conversion,
        SUM(shp_net_sales_eur_currency_conversion) AS shp_net_sales_eur_currency_conversion,
        SUM(shp_net_sales_gbp_currency_conversion) AS shp_net_sales_gbp_currency_conversion,
        SUM(shp_net_sales_usd_currency_conversion) AS shp_net_sales_usd_currency_conversion,
        SUM(shp_total_sales_eur_currency_conversion) AS shp_total_sales_eur_currency_conversion,
        SUM(shp_total_sales_gbp_currency_conversion) AS shp_total_sales_gbp_currency_conversion,
        SUM(shp_total_sales_usd_currency_conversion) AS shp_total_sales_usd_currency_conversion


        from _joined_table
        group by 1, 2, 3, 4
    ),
    _fields as (
        select
            *,
            case
                when master_source_medium like 'google'
                then 'Google Paid'
                when master_source_medium like 'criteo'
                then 'Criteo'
                when master_source_medium like 'bing'
                then 'Microsoft Paid'
                when master_source_medium like 'facebook'
                then 'Meta Paid'
                when master_source_medium like 'FacebookAds'
                then 'Meta Paid'
                when master_source_medium like 'pinterest'
                then 'Pinterest'
                when master_source_medium like 'stackadapt'
                then 'Stackadapt Paid'
                when master_source_medium like 'snapchat'
                then 'Snapchat Paid'
                when master_source_medium like '%referral%'
                then 'referral'
                when master_source_medium like '%Referral%'
                then 'referral'
                when master_source_medium like '%organic%'
                then 'organic'
                when master_source_medium like '%social%'
                then 'social'
                when master_source_medium like '%Social%'
                then 'social'
                when master_source_medium like '%email%'
                then 'email'
                when master_source_medium like 'tiktok'
                then 'TikTok Paid'
                when master_source_medium like '%(direct) / (none)%'
                then 'direct'
                when master_source_medium like 'affiliate'
                then 'Affiliate'
                when master_source_medium like 'shareasale'
                then 'Affiliate'
                when master_source_medium like 'shopstyle'
                then 'Affiliate'
                when master_source_medium like 'lyst'
                then 'Affiliate'
                when master_source_medium like 'linkby'
                then 'Affiliate'
                when master_source_medium like 'awin'
                then 'Affiliate'
                else 'other'
            end as new_source_grouping,
            {{
                dbt_utils.surrogate_key(
                    ["master_date", "master_ga_accountname", "master_source_medium", "Final_reporting_currency"]
                )
            }} as surrogate_key
        from _agg_join
    )

select *
from _fields
