select

    date as ga_date,
    account as ga_account,
    account_id as ga_account_id,
    source_medium as ga_source_medium,
    campaign as ga_campaign,
    transaction_id as ga_transaction_id,
    item_revenue as ga_item_revenue,
    session as ga_session,
    transaction_revenue as ga_transaction_revenue,
    transaction as ga_transaction

from {{ source("supermetrics", "GA_CAMPAIGN_TRANSACTION_ID_SOURCE_M_*") }}
