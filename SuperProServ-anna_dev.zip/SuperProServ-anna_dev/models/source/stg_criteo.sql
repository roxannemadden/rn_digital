select

    advertiser_id as criteo_account_id,
    advertiser_name as criteo_account_name,
    adset_id as criteo_ad_group_id,
    adset_name as criteo_ad_group_name,
    cast(null as string) as criteo_ad_id,
    cast(null as string) as criteo_ad_title,
    campaign_id as criteo_campaign_id,
    campaign_name as criteo_campaign_name,
    data_source_name as criteo_data_source_name,
    date as criteo_date,
    cost as criteo_spend,
    t_cost_eur_currency_conversion as criteo_cost_eur_conversion,
    t_cost_gbp_currency_conversion as criteo_cost_gbp_conversion,
    t_cost_usd_currency_conversion as criteo_cost_usd_conversion

from {{ source("supermetrics", "CRI_COST_DATA_CRI_*") }}
