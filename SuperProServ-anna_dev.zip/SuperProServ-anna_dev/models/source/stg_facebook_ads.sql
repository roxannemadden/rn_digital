select
    profile_id as facebook_account_id,
    profile as facebook_account_name,
    ad_group_id as facebook_ad_group_id,
    ad_group_name as facebook_ad_group_name,
    ad_id as facebook_ad_id,
    ad_name as facebook_ad_title,
    campaign_id as facebook_campaign_id,
    campaign_name as facebook_campaign_name,
    data_source_name as facebook_data_source_name,
    date as facebook_date,
    cost as facebook_spend,
    t_cost_eur_currency_conversion as facebook_cost_eur_conversion, 
    t_cost_gbp_currency_conversion as facebook_cost_gbp_conversion, 
    t_cost_usd_currency_conversion as facebook_cost_usd_conversion


from {{ source("supermetrics", "FBADS_COST_DATA_*") }}
