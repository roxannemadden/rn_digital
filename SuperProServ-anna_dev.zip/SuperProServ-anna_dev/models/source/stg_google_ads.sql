select
    account_name as google_ads_account_name,
    campaign_id as google_ads_campaign_id,
    campaign_name as google_ads_campaign_name,
    data_source_name as google_ads_data_source_name,
    date as google_ads_date,
    profile as google_ads_profile,
    profile_id as google_ads_account_id,
    cost as google_ads_cost, 
    t_cost_eur_currency_conversion as google_ads_cost_eur_conversion,
    t_cost_gbp_currency_conversion as google_ads_cost_gbp_conversion,
    t_cost_usd_currency_conversion as google_ads_cost_usd_conversion


from {{ source("supermetrics", "GOOGLEADS_CAMPAIGN_LEVEL_COST_*") }}
