select

    date as ga4_date,
    data_source_name as data_source_name,
    property_name as ga4_profile,
    propertyID as ga4_profile_id,
    sessionSourceMedium as ga4_source,
    sessionCampaignName as ga4_campaign_name,
    SUM(purchaserevenue) as purchaserevenue,
    SUM(transactions) as transactions, 
    SUM(t_eur_gbp_converted_revenue) as ga4_eur_gbp_converted_revenue,
    SUM(t_eur_usd_converted_revenue) as ga4_eur_usd_converted_revenue, 
    SUM(t_gbp_eur_converted_revenue) as ga4_gbp_eur_converted_revenue, 
    SUM(t_gbp_usd_converted_revenue) as ga4_gbp_usd_converted_revenue, 
    SUM(t_usd_eur_converted_revenue) as ga4_usd_eur_converted_revenue, 
    SUM(t_usd_gbp_converted_revenue) as ga4_usd_gbp_converted_revenue

from {{ source("supermetrics", "GAWA_KEY_METRICS_BY_ACCOUNT_NAME_GA4_*") }}

group by 1, 2, 3, 4, 5, 6
