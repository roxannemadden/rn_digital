select

    date as ga4_date,
    data_source_name as data_source_name,
    account_name as ga4_account,
    accountId as ga4_account_id,
    sessionSourceMedium as ga4_source_medium,
    transaction_id as ga4_transaction_id,
    sessionCampaignName as ga4_campaign,
    sum(purchaseRevenue) as purchaserevenue,
    sum(transactions) as transactions

from {{ source("supermetrics", "GAWA_KEY_METRICS_BY_ACCOUNT_NAME_GA4_*") }}

group by 1, 2, 3, 4, 5, 6, 7