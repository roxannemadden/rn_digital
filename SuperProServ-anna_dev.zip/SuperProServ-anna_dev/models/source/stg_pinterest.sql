select
    account_id as pinterest_account_id,
    account_name as pinterest_account_name,
    campaign_id as pinterest_campaign_id,
    campaign_name as pinterest_campaign_name,
    data_source_name as pinterest_data_source_name,
    date as pinterest_date,
    cost as pinterest_spend,
    cost as pinterest_cost_eur_conversion,
    cost as pinterest_cost_gbp_conversion,
    cost as pinterest_cost_usd_conversion

from {{ source("supermetrics", "PIA_PIA_KEY_METRICS_*") }}
