select
    advertiser_id as stackadapt_account_id,
    advertiser as stackadapt_account_name,
    campaign as stackadapt_campaign_name,
    cast(null as string) as stackadapt_campaign_id,
    datasourcename as stackadapt_data_source_name,
    date as stackadapt_date,
    cost as stackadapt_spend,
    cost as stackadapt_cost_eur_conversion,
    cost as stackadapt_cost_gbp_conversion,
    cost as stackadapt_cost_usd_conversion


from {{ source("supermetrics", "STAC_SA_KEY_METRICS_*") }}
