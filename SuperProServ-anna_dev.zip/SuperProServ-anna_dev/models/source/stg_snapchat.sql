select
    account_id as snapchat_account_id,
    account_name as snapchat_account_name,
    campaign_id as snapchat_campaign_id,
    campaign_name as snapchat_campaign_name,
    data_source_name as snapchat_data_source_name,
    date as snapchat_date,
    cost as snapchat_spend,
    cost as snapchat_cost_eur_conversion, 
    cost as snapchat_cost_gbp_conversion, 
    cost as snapchat_cost_usd_conversion


from {{ source("supermetrics", "SCM_SNAPCHAT_ADS_COST_DATA_*") }}
