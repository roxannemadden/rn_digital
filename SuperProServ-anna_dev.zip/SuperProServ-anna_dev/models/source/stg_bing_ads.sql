select
    date as bing_date,
    account_id as bing_account_id,
    account_name as bing_account_name,
    ad_group_id as bing_ad_group_id,
    ad_group_name as bing_ad_group_name,
    ad_id as bing_ad_id,
    ad_title as bing_ad_title,
    campaign_id as bing_campaign_id,
    campaign_name as bing_campaign_name,
    data_source_name as bing_data_source_name,
    spend as bing_spend, 
    t_cost_eur_currency_conversion as bing_cost_eur_conversion, 
    t_cost_gbp_currency_conversion as bing_cost_gbp_conversion,
    t_cost_usd_currency_conversion as bing_cost_usd_conversion
    
from {{ source("supermetrics", "BINGADS_KEY_METRICS_*") }}
