select
    advertiser_id as tiktok_account_id,
    advertiser_name as tiktok_account_name,
    campaign_id as tiktok_campaign_id,
    campaign_name as tiktok_campaign_name,
    datasourcename as tiktok_data_source_name,
    date as tiktok_date,
    cost as tiktok_spend,
    t_cost_eur_currency_conversion as tiktok_cost_eur_conversion,
    t_cost_gbp_currency_conversion as tiktok_cost_gbp_conversion,
    t_cost_usd_currency_conversion as tiktok_cost_usd_conversion

from {{ source("supermetrics", "TIK_KEY_METRICS_TIKTOK_*") }}
