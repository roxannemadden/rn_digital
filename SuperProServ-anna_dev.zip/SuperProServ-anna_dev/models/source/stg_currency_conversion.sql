select 

    date as date, 
    CAST(EUR_USD AS NUMERIC) AS EUR_USD,
    CAST(USD_EUR AS NUMERIC) AS USD_EUR,
    CAST(USD_GBP AS NUMERIC) AS USD_GBP,
    CAST(GBP_USD AS NUMERIC) AS GBP_USD,
    CAST(GBP_EUR AS NUMERIC) AS GBP_EUR,
    CAST(EUR_GBP AS NUMERIC) AS EUR_GBP


from {{ source("supermetrics", "Currency_conversion") }}