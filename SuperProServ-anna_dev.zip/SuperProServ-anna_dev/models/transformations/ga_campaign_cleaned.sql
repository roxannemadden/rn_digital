-- -get a list of all campaign names currently present in the marketing data union
-- model
with
    a as (
        select distinct campaign_name from {{ ref("marketing_union_mapped_patched") }}
    ),

    -- -use the list of valid campaign names as a filter for the GA data to remove any
    -- entries that belong to earlier
    -- -versions of the campaigns

    b as (
        select * except (ga_source_medium),
    case
        when ga_source_medium like '%facebook / cpc%'
        then 'facebook'
        when ga_source_medium like '%facebook / paid%'
        then 'facebook'
        when ga_source_medium like '%fb / paid%'
        then 'facebook'
        when ga_source_medium like '%bing / cpc%'
        then 'bing'
        when ga_source_medium like '%google / cpc%'
        then 'google'
        when ga_source_medium like '%Criteo%'
        then 'criteo'
        when ga_source_medium like '%criteo%'
        then 'criteo'
        when ga_source_medium like '%tiktok / (not set)%'
        then 'tiktok'
        when ga_source_medium like '%ads.pinterest.com%'
        then 'pinterest'
        when ga_source_medium like '%stackadapt%'
        then 'stackadapt'
        when ga_source_medium like '%snapchat / cpc	%'
        then 'snapchat'

        else ga_source_medium
    end as ga_source_medium,

    (ga_transaction_id || ga_account_id) as unique_transaction_id

        from {{ ref("stg_ga_transaction_by_view") }}
        -- -get also the entries where campaign is not set at all back in
        where ga_campaign in (select campaign_name from a) or ga_campaign IS NOT NULL
        
    )

select * from b
