{{ config(materialized="table") }}

WITH 

facebook_ads_data AS ( SELECT * FROM {{ ref('stg_facebook_ads') }}), 
bing_ads_data AS (SELECT * FROM {{ ref('stg_bing_ads') }}), 
google_ads_data AS (SELECT * FROM {{ ref("stg_google_ads") }}), 
criteo_data AS (SELECT * FROM {{ ref("stg_criteo") }}), 
pinterest_ads_data AS (SELECT * FROM {{ ref("stg_pinterest") }}), 
tiktok_ads_data AS (SELECT * FROM {{ ref("stg_tiktok") }}), 
stackadapt_data AS (SELECT * FROM {{ ref("stg_stackadapt") }}), 
snapchat_data AS (SELECT * FROM {{ ref("stg_snapchat") }}), 


facebook_ads_data_grouped AS 

    (SELECT
        facebook_account_id AS account_id, 
        facebook_account_name AS account_name, 
        facebook_campaign_id AS campaign_id, 
        facebook_campaign_name AS campaign_name,  
        facebook_data_source_name AS data_source_name,  
        facebook_date AS date,  
        sum(facebook_spend) AS cost, 
        sum(facebook_cost_eur_conversion) AS cost_eur_conversion, 
        sum(facebook_cost_gbp_conversion) AS cost_gbp_conversion,
        sum(facebook_cost_usd_conversion) AS cost_usd_conversion,

    FROM facebook_ads_data
    GROUP BY 1, 2, 3, 4, 5, 6), 

bing_ads_data_grouped AS (
    
    SELECT
        bing_account_id AS account_id,		
        bing_account_name AS account_name,			
        bing_campaign_id AS campaign_id,
        bing_campaign_name AS campaign_name,
        bing_data_source_name AS data_source_name,
        bing_date AS date,
        sum(bing_spend) AS cost, 
        sum(bing_cost_eur_conversion) AS cost_eur_conversion, 
        sum(bing_cost_gbp_conversion) AS cost_gbp_conversion,
        sum(bing_cost_usd_conversion) AS cost_usd_conversion

    FROM bing_ads_data
    GROUP BY 1, 2, 3, 4, 5, 6),

google_ads_data_grouped AS (

    SELECT
        google_ads_account_id AS account_id,  
        google_ads_profile AS account_name, 
        google_ads_campaign_id AS campaign_id,
        google_ads_campaign_name AS campaign_name,
        google_ads_data_source_name AS data_source_name,
        google_ads_date AS date,
        sum(google_ads_cost) AS cost, 
        sum(google_ads_cost_eur_conversion) AS cost_eur_conversion, 
        sum(google_ads_cost_gbp_conversion) AS cost_gbp_conversion,
        sum(google_ads_cost_usd_conversion) AS cost_usd_conversion

    FROM google_ads_data
    GROUP BY 1, 2, 3, 4, 5, 6),

criteo_data_grouped AS (
    
    SELECT
        criteo_account_id AS account_id,
        criteo_account_name AS account_name,
        criteo_ad_group_id AS campaign_id,
        criteo_ad_group_name AS campaign_name,
        criteo_data_source_name AS data_source_name,
        criteo_date AS date,
        sum(criteo_spend) AS cost, 
        sum(criteo_cost_eur_conversion) AS cost_eur_conversion,       
        sum(criteo_cost_gbp_conversion) AS cost_gbp_conversion,
        sum(criteo_cost_usd_conversion) AS cost_usd_conversion

    FROM criteo_data
    GROUP BY 1, 2, 3, 4, 5, 6),

pinterest_data_grouped AS (

    SELECT
        pinterest_account_id AS account_id,
        pinterest_account_name AS account_name,
        pinterest_campaign_id AS campaign_id,
        pinterest_campaign_name AS campaign_name,
        pinterest_data_source_name AS data_source_name,
        pinterest_date AS date,
        sum(pinterest_spend) AS cost,
        sum(pinterest_cost_eur_conversion) AS cost_eur_conversion,
        sum(pinterest_cost_gbp_conversion) AS cost_gbp_conversion, 
        sum(pinterest_cost_usd_conversion) AS cost_usd_conversion

    FROM pinterest_ads_data
    GROUP BY 1, 2, 3, 4, 5, 6),

tiktok_ads_data_grouped AS (

    SELECT
        tiktok_account_id AS account_id,
        tiktok_account_name AS account_name,
        tiktok_campaign_id AS campaign_id,
        tiktok_campaign_name AS campaign_name,
        tiktok_data_source_name AS data_source_name,
        tiktok_date AS date,
        sum(tiktok_spend) AS cost, 
        sum(tiktok_cost_eur_conversion) AS cost_eur_conversion,
        sum(tiktok_cost_gbp_conversion) AS cost_gbp_conversion, 
        sum(tiktok_cost_usd_conversion) AS cost_usd_conversion

    FROM tiktok_ads_data

    GROUP BY 1, 2, 3, 4, 5, 6),

stackadapt_data_grouped AS (

    SELECT
        stackadapt_account_id AS account_id,
        stackadapt_account_name AS account_name,
        stackadapt_campaign_id AS campaign_id,
        stackadapt_campaign_name AS campaign_name,
        stackadapt_data_source_name AS data_source_name,
        stackadapt_date AS date,
        sum(stackadapt_spend) AS cost, 
        sum(stackadapt_cost_eur_conversion) AS cost_eur_conversion,
        sum(stackadapt_cost_gbp_conversion) AS cost_gbp_conversion, 
        sum(stackadapt_cost_usd_conversion) AS cost_usd_conversion    

    FROM stackadapt_data

    GROUP BY 1, 2, 3, 4, 5, 6), 

snapchat_ads_data_grouped AS (

    SELECT

        snapchat_account_id AS account_id,
        snapchat_account_name AS account_name,
        snapchat_campaign_id AS campaign_id,
        snapchat_campaign_name AS campaign_name,
        snapchat_data_source_name AS data_source_name,
        snapchat_date AS date,
        sum(snapchat_spend) AS cost,
        sum(snapchat_cost_eur_conversion) AS cost_eur_conversion,
        sum(snapchat_cost_gbp_conversion) AS cost_gbp_conversion, 
        sum(snapchat_cost_usd_conversion) AS cost_usd_conversion  


    FROM snapchat_data

    GROUP BY 1, 2, 3, 4, 5, 6), 

ads_data_unioned AS 

(SELECT * FROM facebook_ads_data_grouped
    UNION ALL
    SELECT * FROM bing_ads_data_grouped
    UNION ALL
    SELECT * FROM google_ads_data_grouped
    UNION ALL
    SELECT * FROM criteo_data_grouped
    UNION ALL
    SELECT * FROM pinterest_data_grouped
    UNION ALL
    SELECT * FROM tiktok_ads_data_grouped
    UNION ALL
    SELECT * FROM stackadapt_data_grouped
    UNION ALL
    SELECT * FROM snapchat_ads_data_grouped)

SELECT * FROM ads_data_unioned

