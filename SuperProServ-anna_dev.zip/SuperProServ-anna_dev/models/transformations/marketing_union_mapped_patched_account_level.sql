with marketing_union_mapped_patched as (
    select * from {{ ref('marketing_union_mapped_patched') }}
),

_agg as (
SELECT  
marketing_date,
marketing_source,
Google_Analytics_account_id,
account_id,
Final_reporting_currency as Final_reporting_currency, --which currency the cost was converted to according to the mapping table
COALESCE(m_ga_account_name, account_name) as master_account_name,
-- helps aggregate the data on the account level to keet the cost data for campaigns names with (not set)
SUM(cost) as cost,
sum(cost_eur_conversion) AS cost_eur_conversion,
sum(cost_gbp_conversion) AS cost_gbp_conversion, 
sum(cost_usd_conversion) AS cost_usd_conversion
 

FROM marketing_union_mapped_patched
GROUP BY 1,2,3,4,5,6)

select *,
{{
    dbt_utils.surrogate_key(
        [
            'marketing_date',
            'master_account_name',
            'marketing_source',
            'Google_Analytics_account_id',
            'account_id'
        ]
    )
}} as surrogate_key
from _agg

