{{ config(materialized="table") }}

with

    -- SOURCE TABLES
    union_marketing_data as (select * from {{ ref("new_union_marketing_data") }}),

    mapping as (
        select 

            Client_, 
            Google_Analytics_account_id, 
            Platform, 
            Secondary_profile_id, 
            Ad_Platform_Default_Currency, 
            Final_reporting_currency
        
        from {{ source("supermetrics", "GS_account_mapping_currency") }}
        -- removing three accounts that are shared across two client names, to be
        -- patched in separate step

        where secondary_profile_id not in ('1672475754', '141180051', '1442477537')
        
        group by 

            Client_, 
            Google_Analytics_account_id, 
            Platform, 
            Secondary_profile_id, 
            Ad_Platform_Default_Currency, 
            Final_reporting_currency),

    add_helper_columns as (
        select
            *,
            case
                when data_source_name like '%Facebook%'
                then 'facebook'
                when data_source_name like '%Microsoft Advertising (Bing)%'
                then 'bing'
                when data_source_name like '%Google Ads%'
                then 'google'
                when data_source_name like '%Criteo%'
                then 'criteo'
                when data_source_name like '%criteo%'
                then 'criteo'
                when data_source_name like '%TikTok Ads%'
                then 'tiktok'
                when data_source_name like '%Pinterest Ads%'
                then 'pinterest'
                when data_source_name like '%StackAdapt%'
                then 'stackadapt'
                when data_source_name like '%Snapchat Marketing%'
                then 'snapchat'
                else data_source_name
            end as marketing_source,
            case
                when data_source_name like '%Facebook%'
                then 'cpc'
                when data_source_name like '%Microsoft Advertising (Bing)%'
                then 'cpc'
                when data_source_name like '%Google Ads%'
                then 'cpc'
                else data_source_name
            end as marketing_medium,
        from union_marketing_data
    ),

    joined_table as (
        select add_helper_columns.*, mapping.*
        from add_helper_columns
        left join
            mapping on add_helper_columns.account_id = mapping.secondary_profile_id
    -- AND add_helper_columns.marketing_source = mapping.Platform
    ),

    campaign_name_geo as (

        select
            *,
            case
                when campaign_name like '%UK%'
                then 'United Kingdom'
                when campaign_name like '%US%'
                then 'USA'
                when campaign_name like '%IE%'
                then 'Ireland'
                when campaign_name like '%IRE%'
                then 'Ireland'
                when campaign_name like '%AUS & NZ%'
                then 'Australia and New Zealand'
                when campaign_name like '%ANZ%'
                then 'Australia and New Zealand'
                when campaign_name like '%DACH%'
                then 'DACH'
                when campaign_name like '%DE, AT & CH%'
                then 'DACH'
                when campaign_name like '%ASIA HK & SG%'
                then 'Hong Kong and Singapore'
                when campaign_name like '%APAC%'
                then 'Hong Kong and Singapore'
                when campaign_name like '%UAE%'
                then 'United Arab Emirates'
                when campaign_name like '%EU%'
                then 'European Union'
                when campaign_name like '%DE%'
                then 'Germany'
                when campaign_name like '%NL%'
                then 'Netherlands'
                when campaign_name like '%FR%'
                then 'France'
                when campaign_name like '%DE & NL%'
                then 'Germany and Netherlands'
                when campaign_name like '%MIDDLE EAST%'
                then 'Middle East'
                when campaign_name like '%ME%'
                then 'Middle East'
                when campaign_name like '%NA CA%'
                then 'North America and Canada'
                when campaign_name like '%CZ%'
                then 'Czech'
                when campaign_name like '%PL%'
                then 'Poland'
                when campaign_name like '%AUS%'
                then 'Australia'
                when campaign_name like '%AU%'
                then 'Australia'
                when campaign_name like '%CA%'
                then 'Canada'
                when campaign_name like '%SG%'
                then 'Singapore'
                when campaign_name like '%ASIA SG%'
                then 'Singapore'
                when campaign_name like '%BE%'
                then 'Belgium'
                when campaign_name like '%BEL%'
                then 'Belgium'
                when account_name like '%NZ%'
                then 'New Zealand'
            end as campaign_name_geo_mapping

        from joined_table
    ),

    _account_name_geo as (

        select
            *,
            case
                
                when Client_ like '%UK%'
                then 'United Kingdom'
                when Client_ like '%US%'
                then 'USA'
                when Client_ like '%IE%'
                then 'Ireland'
                when Client_ like '%IRE%'
                then 'Ireland'
                when Client_ like '%AUS & NZ%'
                then 'Australia and New Zealand'
                when Client_ like '%ANZ%'
                then 'Australia and New Zealand'
                when Client_ like '%DACH%'
                then 'DACH'
                when Client_ like '%DE, AT & CH%'
                then 'DACH'
                when Client_ like '%ASIA HK & SG%'
                then 'Hong Kong and Singapore'
                when Client_ like '%APAC%'
                then 'Hong Kong and Singapore'
                when Client_ like '%UAE%'
                then 'United Arab Emirates'
                when Client_ like '%EU%'
                then 'European Union'
                when Client_ like '%DE%'
                then 'Germany'
                when Client_ like '%NL%'
                then 'Netherlands'
                when Client_ like '%FR%'
                then 'France'
                when Client_ like '%DE & NL%'
                then 'Germany and Netherlands'
                when Client_ like '%MIDDLE EAST%'
                then 'Middle East'
                when Client_ like '%ME%'
                then 'Middle East'
                when Client_ like '%NA CA%'
                then 'North America and Canada'
                when Client_ like '%CZ%'
                then 'Czech'
                when Client_ like '%PL%'
                then 'Poland'
                when Client_ like '%AUS%'
                then 'Australia'
                when Client_ like '%AU%'
                then 'Australia'
                when Client_ like '%CA%'
                then 'Canada'
                when Client_ like '%SG%'
                then 'Singapore'
                when Client_ like '%ASIA SG%'
                then 'Singapore'
                when Client_ like '%BE%'
                then 'Belgium'
                when Client_ like '%BEL%'
                then 'Belgium'
                when Client_ like '%NZ%'
                then 'New Zealand'

            end as account_name_geo_mapping
            from campaign_name_geo
    ),



    joined_table_unique_accounts as (
        select
            date as date,
            client_ as m_ga_account_name,
            safe_cast(google_analytics_account_id as string) as google_analytics_account_id,
            Ad_Platform_Default_Currency, 
            Final_reporting_currency,
            marketing_source as marketing_source,
            account_id,
            account_name,
            campaign_name as campaign_name,
            coalesce(account_name_geo_mapping, campaign_name_geo_mapping) as campaign_name_geo_mapping,
            sum(cost) as cost, 
            sum(cost_eur_conversion) AS cost_eur_conversion,
            sum(cost_gbp_conversion) AS cost_gbp_conversion, 
            sum(cost_usd_conversion) AS cost_usd_conversion 
        from _account_name_geo
        group by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
    )

select
    date,
    marketing_source,
    google_analytics_account_id,
    Ad_Platform_Default_Currency,
    Final_reporting_currency,
    account_id,
    account_name,
    m_ga_account_name,
    campaign_name,
    campaign_name_geo_mapping,
    sum(cost) as cost,
    sum(cost_eur_conversion) AS cost_eur_conversion,
    sum(cost_gbp_conversion) AS cost_gbp_conversion, 
    sum(cost_usd_conversion) AS cost_usd_conversion, 
    count(*) as m_count_all
from joined_table_unique_accounts
group by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
order by m_count_all desc