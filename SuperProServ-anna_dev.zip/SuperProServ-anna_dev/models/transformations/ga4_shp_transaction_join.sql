

WITH

    /* SOURCE TABLES */

    ga4_transaction_data AS (

    SELECT 
        ga4_date,       
        Client, 
        ga4_campaign, 
        ga4_source_medium,
        ga4_account_id, 
        unique_transaction_id,
        SUM(purchaserevenue) AS purchaserevenue, 
        SUM(transactions) AS transactions

    FROM {{ ref('gawa_mapping') }}
    GROUP BY 1,2,3,4,5,6
    ),

    shp_data_mapped_ga4_account AS (
    SELECT 
        date,
        Google_Analytics_account_id,
        shp_order_is_returning_customer,
        unique_shp_transaction_id,
        SUM(shp_discounts) AS shp_discounts, 
        SUM(shp_gross_sales) AS shp_gross_sales,
        SUM(shp_net_sales) AS shp_net_sales, 
        SUM(shp_total_sales) AS shp_total_sales,
        SUM(shp_returns) AS shp_returns,
        SUM(shp_shipping) AS shp_shipping,
        SUM(shp_sm_order_count) AS shp_sm_order_count,
        SUM(shp_tax) AS shp_tax, 
        SUM(shp_gross_sales_eur_currency_conversion) AS shp_gross_sales_eur_currency_conversion,
        SUM(shp_gross_sales_gbp_currency_conversion) AS shp_gross_sales_gbp_currency_conversion,
        SUM(shp_gross_sales_usd_currency_conversion) AS shp_gross_sales_usd_currency_conversion,
        SUM(shp_net_sales_eur_currency_conversion) AS shp_net_sales_eur_currency_conversion,
        SUM(shp_net_sales_gbp_currency_conversion) AS shp_net_sales_gbp_currency_conversion,
        SUM(shp_net_sales_usd_currency_conversion) AS shp_net_sales_usd_currency_conversion,
        SUM(shp_total_sales_eur_currency_conversion) AS shp_total_sales_eur_currency_conversion,
        SUM(shp_total_sales_gbp_currency_conversion) AS shp_total_sales_gbp_currency_conversion,
        SUM(shp_total_sales_usd_currency_conversion) AS shp_total_sales_usd_currency_conversion    
        
    FROM {{ ref('shp_gawa_mapping') }}
    GROUP BY 1,2,3,4
    ),

    joined_table as (
        select
            ga4_transaction_data.ga4_date, 
            ga4_transaction_data.Client,
            ga4_transaction_data.ga4_account_id, 
            ga4_transaction_data.ga4_campaign,
            ga4_transaction_data.ga4_source_medium,
            ga4_transaction_data.purchaserevenue, 
            ga4_transaction_data.transactions,
            ga4_transaction_data.unique_transaction_id,
            shp_data_mapped_ga4_account.unique_shp_transaction_id,
            shp_data_mapped_ga4_account.date, 
            shp_data_mapped_ga4_account.shp_order_is_returning_customer, 
            shp_data_mapped_ga4_account.shp_discounts, 
            shp_data_mapped_ga4_account.shp_gross_sales, 
            shp_data_mapped_ga4_account.shp_net_sales, 
            shp_data_mapped_ga4_account.shp_returns, 
            shp_data_mapped_ga4_account.shp_shipping, 
            shp_data_mapped_ga4_account.shp_sm_order_count,
            shp_data_mapped_ga4_account.shp_tax,
            shp_data_mapped_ga4_account.shp_total_sales,
            shp_data_mapped_ga4_account.shp_gross_sales_eur_currency_conversion, 
            shp_data_mapped_ga4_account.shp_gross_sales_gbp_currency_conversion,
            shp_data_mapped_ga4_account.shp_gross_sales_usd_currency_conversion,
            shp_data_mapped_ga4_account.shp_net_sales_eur_currency_conversion,
            shp_data_mapped_ga4_account.shp_net_sales_gbp_currency_conversion,
            shp_data_mapped_ga4_account.shp_net_sales_usd_currency_conversion,
            shp_data_mapped_ga4_account.shp_total_sales_eur_currency_conversion,
            shp_data_mapped_ga4_account.shp_total_sales_gbp_currency_conversion,
            shp_data_mapped_ga4_account.shp_total_sales_usd_currency_conversion


        FROM ga4_transaction_data
        LEFT JOIN
            shp_data_mapped_ga4_account
            ON ga4_transaction_data.unique_transaction_id
            = shp_data_mapped_ga4_account.unique_shp_transaction_id),

ga4_shp_data_grouped AS (

    SELECT
        ga4_date,       
        Client, 
        ga4_campaign, 
        ga4_source_medium,
        ga4_account_id,
        shp_order_is_returning_customer,
        SUM(purchaserevenue) AS purchaserevenue, 
        SUM(transactions) AS transactions,
        SUM(shp_discounts) AS shp_discounts, 
        SUM(shp_gross_sales) AS shp_gross_sales,
        SUM(shp_net_sales) AS shp_net_sales, 
        SUM(shp_total_sales) AS shp_total_sales,
        SUM(shp_returns) AS shp_returns,
        SUM(shp_shipping) AS shp_shipping,
        SUM(shp_sm_order_count) AS shp_sm_order_count,
        SUM(shp_tax) AS shp_tax, 
        SUM(shp_gross_sales_eur_currency_conversion) AS shp_gross_sales_eur_currency_conversion,
        SUM(shp_gross_sales_gbp_currency_conversion) AS shp_gross_sales_gbp_currency_conversion,
        SUM(shp_gross_sales_usd_currency_conversion) AS shp_gross_sales_usd_currency_conversion,
        SUM(shp_net_sales_eur_currency_conversion) AS shp_net_sales_eur_currency_conversion,
        SUM(shp_net_sales_gbp_currency_conversion) AS shp_net_sales_gbp_currency_conversion,
        SUM(shp_net_sales_usd_currency_conversion) AS shp_net_sales_usd_currency_conversion,
        SUM(shp_total_sales_eur_currency_conversion) AS shp_total_sales_eur_currency_conversion,
        SUM(shp_total_sales_gbp_currency_conversion) AS shp_total_sales_gbp_currency_conversion,
        SUM(shp_total_sales_usd_currency_conversion) AS shp_total_sales_usd_currency_conversion
        
    FROM joined_table
    GROUP BY 1,2,3,4,5,6
),

_surrogate_key AS 
    (SELECT *, 
        {{dbt_utils.surrogate_key([
        'ga4_date',
        'Client',
        'ga4_campaign',
        'ga4_source_medium',
        'shp_order_is_returning_customer',
        'ga4_account_id'
    ])
 }} as surrogate_key
    FROM ga4_shp_data_grouped)

select *
from _surrogate_key
