{{ config(materialized="table") }}


-- Source tables

WITH 

marketing_data AS (SELECT * FROM {{ ref('ga_campaign_marketing_union_unique_id') }}), 

-- Add the currency conversion

cost_conversion_table AS ( 
    
    SELECT
        date as marketing_date, 
        marketing_source, 
        google_analytics_account_id, 
        account_id, 
        account_name, 
        m_ga_account_name, 
        campaign_name, 
        campaign_name_geo_mapping, 
        Ad_Platform_Default_Currency,
        Final_reporting_currency, 
        sum(Cost) AS Cost,
        sum(cost_eur_conversion) AS cost_eur_conversion,
        sum(cost_gbp_conversion) AS cost_gbp_conversion, 
        sum(cost_usd_conversion) AS cost_usd_conversion, 

    FROM marketing_data

    GROUP BY 
        marketing_date, 
        marketing_source, 
        google_analytics_account_id, 
        account_id, 
        account_name, 
        m_ga_account_name, 
        campaign_name, 
        campaign_name_geo_mapping, 
        Ad_Platform_Default_Currency,
        Final_reporting_currency)

  SELECT *, 

    {{
        dbt_utils.surrogate_key(
            [
                "marketing_date",
                "marketing_source",
                "google_analytics_account_id",
                "account_id", 
                "campaign_name", 
                "campaign_name_geo_mapping", 
                "m_ga_account_name"
            ]
        )
    }} as surrogate_key

    FROM cost_conversion_table

        