WITH 

-- SOURCE TABLES

shopify_data AS (
  SELECT * 
  FROM {{ ref('shp_order_id_aggregation') }}),

mapping AS (
  SELECT * 
  FROM {{ source('supermetrics', 'SHP_account_mapping') }}
),

joined_table AS (
  SELECT
    shopify_data.*,
    mapping.* 
  FROM shopify_data 
  INNER JOIN mapping ON
    shopify_data.shop_id = mapping.Shopify_account
)

SELECT * EXCEPT (Client, Platform, Shopify_account),
 (order_name||Google_Analytics_account_id	) as unique_shp_transaction_id,
 

FROM joined_table