-- -get a list of all campaign names currently present in the marketing data union
-- model
with
    distinct_campaign_name as (
        select distinct campaign_name from {{ ref("marketing_union_mapped_patched") }}
    ),

    -- -use the list of valid campaign names as a filter for the GA data to remove any
    -- entries that belong to earlier
    -- -versions of the campaigns this step also excludes all entries that come from
    -- traffic sources outside of the marketing sources that we are pulling in like
    -- email or organic
    source_cleanup as (
        select
        * except (ga4_source_medium),

            case
                when ga4_source_medium like '%facebook / cpc%'
                then 'facebook'
                when ga4_source_medium like '%facebook / paid%'
                then 'facebook'
                when ga4_source_medium like '%fb / paid%'
                then 'facebook'
                when ga4_source_medium like '%bing / cpc%'
                then 'bing'
                when ga4_source_medium like '%google / cpc%'
                then 'google'
                when ga4_source_medium like '%Criteo%'
                then 'criteo'
                when ga4_source_medium like '%criteo%'
                then 'criteo'
                when ga4_source_medium like '%tiktok / (not set)%'
                then 'tiktok'
                when ga4_source_medium like '%ads.pinterest.com%'
                then 'pinterest'
                when ga4_source_medium like '%stackadapt%'
                then 'stackadapt'
                when ga4_source_medium like '%snapchat / cpc%'
                then 'snapchat'

                else ga4_source_medium
                end as ga4_source_medium,

            --create a unique transaction id from a combination of ga4_transaction_id and ga4_account_id as a join key to join the ga4 data with Shopify data

                (ga4_transaction_id || ga4_account_id  || ga4_date) as unique_transaction_id

        from {{ ref("ga4_by_account_transaction_cleanup") }}
        where
            ga4_campaign in (select campaign_name from distinct_campaign_name)

            -- -get also the entries where campaign is not set at all back in
          or ga4_campaign IS NOT NULL  
    ), 

    gs_ga4_mapping as (

        SELECT DISTINCT Client, Google_Analytics_account_id
        FROM {{ source('supermetrics', 'GA_GA4_account_mapping') }}
        GROUP BY Client, Google_Analytics_account_id
    ),


account_name_mapping as 

/* 
Joining the Google Analytics 4 data to the mapping table based on Google_Analytics_account_id.
Google Analytics and Google Analytics 4 share the same account ids. 
Google Anaytics 4 profile id and marketing account ids have a many-many relationship in the mapping table,
therefore using GA4 profile_ids is not possible.    
*/

        (select
            source_cleanup.*,
            gs_ga4_mapping.Client
        from source_cleanup
        inner join
            gs_ga4_mapping
            on gs_ga4_mapping.Google_Analytics_account_id = source_cleanup.ga4_account_id),

data_grouping AS (SELECT 
        ga4_date,       
        Client,  
        data_source_name, 
        ga4_campaign, 
        ga4_source_medium,
        ga4_account_id, 
        unique_transaction_id, 
        SUM(purchaserevenue) AS purchaserevenue, 
        SUM(transactions) AS transactions

    FROM account_name_mapping

    GROUP BY 
        ga4_date,       
        Client,
        data_source_name, 
        ga4_campaign, 
        ga4_source_medium,
        ga4_account_id, 
        unique_transaction_id),

_surrogate_key AS 
    (SELECT *, 
        {{dbt_utils.surrogate_key([
        'ga4_date',
        'Client',
        'ga4_campaign',
        'ga4_source_medium',
        'unique_transaction_id'
    ])
 }} as surrogate_key
    FROM data_grouping)
 
SELECT * FROM _surrogate_key 