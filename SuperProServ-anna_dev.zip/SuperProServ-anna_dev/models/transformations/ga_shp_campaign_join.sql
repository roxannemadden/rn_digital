-- Aggregate the transaction-level data to a campaign level
with
    campaign_level_aggregation as

    (
        select

            ga_date as ga_date,
            ga_account as ga_account,
            ga_account_id as ga_account_id,
            ga_source_medium as ga_source_medium,
            ga_campaign as ga_campaign,
            mapped_ga_accountname as mapped_ga_accountname,
            SUM(ga_item_revenue) as item_revenue,
            SUM(ga_transaction_revenue) as ga_transaction_revenue,
            SUM(ga_transaction) as ga_transaction,
            SUM(order_net_sales) as shp_order_net_sales,
            SUM(shp_discounts) as shp_discounts,
            SUM(shp_gross_sales) as shp_gross_sales,
            SUM(shp_net_sales) as shp_net_sales,
            SUM(shp_returns) as shp_returns,
            SUM(shp_shipping) as shp_shipping,
            SUM(shp_sm_order_count) as shp_sm_order_count,
            SUM(shp_tax) as shp_tax,
            SUM(shp_total_sales) as shp_total_sales, 
            SUM(shp_gross_sales_eur_currency_conversion) AS shp_gross_sales_eur_currency_conversion,
            SUM(shp_gross_sales_gbp_currency_conversion) AS shp_gross_sales_gbp_currency_conversion,
            SUM(shp_gross_sales_usd_currency_conversion) AS shp_gross_sales_usd_currency_conversion,
            SUM(shp_net_sales_eur_currency_conversion) AS shp_net_sales_eur_currency_conversion,
            SUM(shp_net_sales_gbp_currency_conversion) AS shp_net_sales_gbp_currency_conversion,
            SUM(shp_net_sales_usd_currency_conversion) AS shp_net_sales_usd_currency_conversion,
            SUM(shp_total_sales_eur_currency_conversion) AS shp_total_sales_eur_currency_conversion,
            SUM(shp_total_sales_gbp_currency_conversion) AS shp_total_sales_gbp_currency_conversion,
            SUM(shp_total_sales_usd_currency_conversion) AS shp_total_sales_usd_currency_conversion

        from {{ ref("ga_shp_transaction_join") }}

        group by 1, 2, 3, 4, 5, 6
    ),

    -- Campaign-level session data 
    sessions_by_campaign as

    (
        select

            ga_date as ga_date_1,
            mapped_ga_accountname as ga_account_1,
            ga_account_id as ga_account_id_1,
            ga_campaign as ga_campaign_1,
            ga_source_medium as ga_source_medium_1,
            SUM(ga_session) as ga_session,

        from {{ ref("ga_sessions_by_campaign_cleaned") }}

        group by 1, 2, 3, 4, 5
    ),

    sessions_data_join as

    (
        select campaign_level_aggregation.*, sessions_by_campaign.*
        from campaign_level_aggregation
        full outer join
            sessions_by_campaign

            on 
            campaign_level_aggregation.ga_campaign = sessions_by_campaign.ga_campaign_1
            and campaign_level_aggregation.ga_date = sessions_by_campaign.ga_date_1
            and campaign_level_aggregation.ga_account_id = sessions_by_campaign.ga_account_id_1
            and campaign_level_aggregation.ga_source_medium = sessions_by_campaign.ga_source_medium_1
    )

select
    COALESCE(ga_date, ga_date_1) as ga_date,
    COALESCE(mapped_ga_accountname, ga_account_1) as ga_account, 
    COALESCE(ga_account_id, ga_account_id_1) as ga_account_id,
    COALESCE(ga_source_medium, ga_source_medium_1) as ga_source_medium,
    COALESCE(ga_campaign, ga_campaign_1) as ga_campaign,
    mapped_ga_accountname as mapped_ga_accountname,
    SUM(ga_session) as ga_session,
    SUM(item_revenue) as item_revenue,
    SUM(ga_transaction_revenue) as ga_transaction_revenue,
    SUM(ga_transaction) as ga_transaction,
    SUM(shp_order_net_sales) as shp_order_net_sales,
    SUM(shp_discounts) as shp_discounts,
    SUM(shp_gross_sales) as shp_gross_sales,
    SUM(shp_net_sales) as shp_net_sales,
    SUM(shp_returns) as shp_returns,
    SUM(shp_shipping) as shp_shipping,
    SUM(shp_sm_order_count) as shp_sm_order_count,
    SUM(shp_tax) as shp_tax,
    SUM(shp_total_sales) as shp_total_sales, 
    SUM(shp_gross_sales_eur_currency_conversion) AS shp_gross_sales_eur_currency_conversion,
    SUM(shp_gross_sales_gbp_currency_conversion) AS shp_gross_sales_gbp_currency_conversion,
    SUM(shp_gross_sales_usd_currency_conversion) AS shp_gross_sales_usd_currency_conversion,
    SUM(shp_net_sales_eur_currency_conversion) AS shp_net_sales_eur_currency_conversion,
    SUM(shp_net_sales_gbp_currency_conversion) AS shp_net_sales_gbp_currency_conversion,
    SUM(shp_net_sales_usd_currency_conversion) AS shp_net_sales_usd_currency_conversion,
    SUM(shp_total_sales_eur_currency_conversion) AS shp_total_sales_eur_currency_conversion,
    SUM(shp_total_sales_gbp_currency_conversion) AS shp_total_sales_gbp_currency_conversion,
    SUM(shp_total_sales_usd_currency_conversion) AS shp_total_sales_usd_currency_conversion

from sessions_data_join
group by 1, 2, 3, 4, 5, 6
