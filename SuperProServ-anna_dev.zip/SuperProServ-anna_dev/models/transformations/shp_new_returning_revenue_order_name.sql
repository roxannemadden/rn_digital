-- fct_shopify
with
    fct_shopify as (select * from {{ ref('shp_order_id_aggregation') }}),

    numbered_shopify as (
        select
            order_name,
            shop_id,
            shp_shop_name,
            unique_order_key,
            shp_order_is_returning_customer AS num_shp_order_is_returning_customer,
            row_number() over (
                partition by unique_order_key order by transaction_date asc
            ) as row_num
        from fct_shopify
    ),

    dim_shopify as (select * from numbered_shopify where row_num = 1),

    unique_order_key_join as (
        select fct_shopify.*, dim_shopify.num_shp_order_is_returning_customer
        from fct_shopify
        left join
            dim_shopify on fct_shopify.unique_order_key = dim_shopify.unique_order_key
    ),

    shopify_unique_order_id as

    (
        select
            order_name,
            shop_id,
            shp_shop_name,
            unique_order_key,
            transaction_date as date,
            num_shp_order_is_returning_customer AS shp_order_is_returning_customer,
            count(*) as count_all,
            sum(order_net_sales) as order_net_sales,
            sum(shp_discounts) as shp_discounts,
            sum(shp_gross_sales) as shp_gross_sales,
            sum(shp_net_sales) as shp_net_sales,
            sum(shp_returns) as shp_returns,
            sum(shp_shipping) as shp_shipping,
            sum(shp_sm_order_count) as shp_sm_order_count,
            sum(shp_tax) as shp_tax,
            sum(shp_total_sales) as shp_total_sales

        from unique_order_key_join

        group by 1, 2, 3, 4, 5, 6
    )

select *
from shopify_unique_order_id
order by count_all desc
