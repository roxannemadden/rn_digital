
WITH 

/* Partitioning the source data by date to source information about the transaction which happened min */

date_partitioning AS (
    SELECT
        ga4_date,
        ga4_transaction_id,
        data_source_name,
        ga4_account, 
        ga4_account_id,
        ga4_source_medium,
        ga4_campaign,
        purchaserevenue,
        transactions, 
        ROW_NUMBER() OVER (PARTITION BY ga4_transaction_id ORDER BY ga4_date) AS rn

    FROM {{ ref('stg_ga4_by_account') }} WHERE ga4_transaction_id != '(not set)' AND ga4_transaction_id != '(other)' AND purchaserevenue IS NOT NULL

    QUALIFY rn = 1)

SELECT * EXCEPT (rn) FROM date_partitioning