WITH 

-- SOURCE TABLES

shopify_data AS (
  SELECT * 
  FROM {{ ref('stg_shopify') }}
),

mapping AS (

  SELECT 
    Google_Analytics_account_id, 
    Shopify_account

  FROM {{ source('supermetrics', 'SHP_account_mapping_currency') }}
  GROUP BY 
    Google_Analytics_account_id, 
    Shopify_account
),

joined_table AS (
  SELECT
    mapping.Google_Analytics_account_id,
    shopify_data.*
  FROM shopify_data 
  INNER JOIN mapping ON
    shopify_data.shop_id = mapping.Shopify_account
)

SELECT 
    date,
    Google_Analytics_account_id,
    shp_order_id,
    shp_order_is_returning_customer,
    order_name,
    shop_id, 
    shp_shop_name,
    (order_name || Google_Analytics_account_id || date) as unique_shp_transaction_id,
    SUM(shp_discounts) AS shp_discounts, 
    SUM(shp_gross_sales) AS shp_gross_sales,
    SUM(shp_net_sales) AS shp_net_sales, 
    SUM(shp_total_sales) AS shp_total_sales,
    SUM(shp_returns) AS shp_returns,
    SUM(shp_shipping) AS shp_shipping,
    SUM(shp_sm_order_count) AS shp_sm_order_count,
    SUM(shp_tax) AS shp_tax, 
    SUM(shp_gross_sales_eur_currency_conversion) AS shp_gross_sales_eur_currency_conversion,
    SUM(shp_gross_sales_gbp_currency_conversion) AS shp_gross_sales_gbp_currency_conversion,
    SUM(shp_gross_sales_usd_currency_conversion) AS shp_gross_sales_usd_currency_conversion,
    SUM(shp_net_sales_eur_currency_conversion) AS shp_net_sales_eur_currency_conversion,
    SUM(shp_net_sales_gbp_currency_conversion) AS shp_net_sales_gbp_currency_conversion,
    SUM(shp_net_sales_usd_currency_conversion) AS shp_net_sales_usd_currency_conversion,
    SUM(shp_total_sales_eur_currency_conversion) AS shp_total_sales_eur_currency_conversion,
    SUM(shp_total_sales_gbp_currency_conversion) AS shp_total_sales_gbp_currency_conversion,
    SUM(shp_total_sales_usd_currency_conversion) AS shp_total_sales_usd_currency_conversion


FROM joined_table

GROUP BY 
    date,
    Google_Analytics_account_id,
    shp_order_id,
    shp_order_is_returning_customer,
    order_name,
    shop_id, 
    shp_shop_name,
    unique_shp_transaction_id