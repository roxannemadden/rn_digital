WITH 

-- SOURCE TABLES

union_marketing_data AS (
  SELECT * 
  FROM {{ ref('new_union_marketing_data') }}
), 

mapping AS (
  SELECT * 
  FROM {{ source('supermetrics', 'GA_GA4_account_mapping') }}
),

_fields AS (
  SELECT 
    account_id, 
    account_name, 
    data_source_name, 
    date, 
    campaign_name,
    SUM(cost) AS cost,
    SUM(cost_eur_conversion) AS cost_eur_conversion,
    SUM(cost_gbp_conversion) AS cost_gbp_conversion, 
    SUM(cost_usd_conversion) AS cost_usd_conversion,  

    CASE 
      WHEN data_source_name LIKE '%Facebook%' THEN 'facebook'
      WHEN data_source_name LIKE '%Microsoft Advertising (Bing)%' THEN 'bing'
      WHEN data_source_name LIKE '%Google Ads%' THEN 'google'
      WHEN data_source_name LIKE '%Criteo%' THEN 'criteo'
      WHEN data_source_name LIKE '%criteo%' THEN 'criteo'
      WHEN data_source_name LIKE '%TikTok Ads%' THEN 'tiktok'
      WHEN data_source_name LIKE '%Pinterest Ads%' THEN 'pinterest'
      WHEN data_source_name LIKE '%StackAdapt%' THEN 'stackadapt'
      WHEN data_source_name LIKE '%Snapchat Marketing%' THEN 'snapchat'
      ELSE data_source_name 
    END AS marketing_source,
     
    CASE
      WHEN data_source_name LIKE '%Facebook%' THEN 'cpc'
      WHEN data_source_name LIKE '%Microsoft Advertising (Bing)%' THEN 'cpc'
      WHEN data_source_name LIKE '%Google Ads%' THEN 'cpc'
      ELSE data_source_name 
    END AS marketing_medium

  FROM union_marketing_data

  GROUP BY 
    account_id, 
    account_name, 
    data_source_name, 
    campaign_name,
    date
),

_join AS (
  SELECT
    _fields.*,
    mapping.* EXCEPT (Secondary_profile_id, Platform, Google_Analytics_account_id, Ad_Platform_Default_Currency)
  FROM _fields 
  
  INNER JOIN mapping ON
    _fields.account_id = mapping.Secondary_profile_id	
),

_surrogate_key AS (
  SELECT 
    date,
    marketing_source,
    Google_Analytics_4_id,
    Client,
    GA4_Default_Currency, 
    campaign_name,
    cost,
    cost_eur_conversion,
    cost_gbp_conversion, 
    cost_usd_conversion, 

    {{dbt_utils.surrogate_key(
        [
            'date',
            'Google_Analytics_4_id',
            'Client',
            'GA4_Default_Currency',
            'marketing_source',
            'campaign_name'
        ]
    )}} AS surrogate_key
  FROM _join
),

_agg AS (

SELECT
    date,
    marketing_source,
    Google_Analytics_4_id,
    Client,
    GA4_Default_Currency,
    campaign_name,
    surrogate_key,
    SUM(cost) AS cost, 
    SUM(cost_eur_conversion) AS cost_eur_conversion,
    SUM(cost_gbp_conversion) AS cost_gbp_conversion, 
    SUM(cost_usd_conversion) AS cost_usd_conversion
  
FROM _surrogate_key
GROUP BY 
    date,
    marketing_source,
    Google_Analytics_4_id,
    Client,
    GA4_Default_Currency,
    campaign_name,
    surrogate_key)

SELECT * FROM _agg
