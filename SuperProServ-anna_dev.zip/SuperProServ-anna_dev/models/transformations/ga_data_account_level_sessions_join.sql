-- Aggregate the transaction-level data to an account level
WITH
    ga_shp_transaction_join AS

    (SELECT * FROM {{ ref('ga_shp_transaction_join') }}),

    ga_sessions_by_campaign_cleaned AS (
        SELECT * FROM {{ ref('ga_sessions_by_campaign_cleaned') }}
    ),

    _agg_ga_shp_transaction_join AS

    (
        SELECT

            ga_date AS ga_date,
            ga_account AS ga_account,
            ga_account_id AS ga_account_id,
            ga_source_medium AS ga_source_medium,
            mapped_ga_accountname AS mapped_ga_accountname,
            SUM(ga_item_revenue) AS item_revenue,
            SUM(ga_transaction_revenue) AS ga_transaction_revenue,
            SUM(ga_transaction) AS ga_transaction,
            SUM(order_net_sales) AS shp_order_net_sales,
            SUM(shp_discounts) AS shp_discounts,
            SUM(shp_gross_sales) AS shp_gross_sales,
            SUM(shp_net_sales) AS shp_net_sales,
            SUM(shp_returns) AS shp_returns,
            SUM(shp_shipping) AS shp_shipping,
            SUM(shp_sm_order_count) AS shp_sm_order_count,
            SUM(shp_tax) AS shp_tax,
            SUM(shp_total_sales) AS shp_total_sales,
            SUM(shp_gross_sales_eur_currency_conversion) AS shp_gross_sales_eur_currency_conversion,
            SUM(shp_gross_sales_gbp_currency_conversion) AS shp_gross_sales_gbp_currency_conversion,
            SUM(shp_gross_sales_usd_currency_conversion) AS shp_gross_sales_usd_currency_conversion,
            SUM(shp_net_sales_eur_currency_conversion) AS shp_net_sales_eur_currency_conversion,
            SUM(shp_net_sales_gbp_currency_conversion) AS shp_net_sales_gbp_currency_conversion,
            SUM(shp_net_sales_usd_currency_conversion) AS shp_net_sales_usd_currency_conversion,
            SUM(shp_total_sales_eur_currency_conversion) AS shp_total_sales_eur_currency_conversion,
            SUM(shp_total_sales_gbp_currency_conversion) AS shp_total_sales_gbp_currency_conversion,
            SUM(shp_total_sales_usd_currency_conversion) AS shp_total_sales_usd_currency_conversion

        FROM ga_shp_transaction_join

        GROUP BY 1, 2, 3, 4, 5
    ),

    -- Account-level session data 
    _agg_ga_sessions_by_campaign_cleaned AS

    (
        SELECT

            ga_date AS ga_date_1,
            mapped_ga_accountname AS ga_account_1,
            ga_account_id AS ga_account_id_1,
            ga_source_medium AS ga_source_medium_1,
            SUM(ga_session) AS ga_session,

        FROM ga_sessions_by_campaign_cleaned

        GROUP BY 1, 2, 3, 4
    ),

    sessions_data_join AS

    (
        SELECT _agg_ga_shp_transaction_join.*, _agg_ga_sessions_by_campaign_cleaned.*
        FROM _agg_ga_shp_transaction_join
        full outer join
            _agg_ga_sessions_by_campaign_cleaned

            on _agg_ga_shp_transaction_join.ga_date
            = _agg_ga_sessions_by_campaign_cleaned.ga_date_1
            and _agg_ga_shp_transaction_join.ga_account_id
            = _agg_ga_sessions_by_campaign_cleaned.ga_account_id_1
            and _agg_ga_shp_transaction_join.ga_source_medium
            = _agg_ga_sessions_by_campaign_cleaned.ga_source_medium_1
    )

SELECT
    COALESCE(ga_date, ga_date_1) AS ga_date,
    COALESCE(mapped_ga_accountname, ga_account_1) AS ga_account,
    COALESCE(ga_account_id, ga_account_id_1) AS ga_account_id,
    COALESCE(ga_source_medium, ga_source_medium_1)  AS ga_source_medium,
    mapped_ga_accountname,
    SUM(ga_session) AS ga_session,
    SUM(item_revenue) AS item_revenue,
    SUM(ga_transaction_revenue) AS ga_transaction_revenue,
    SUM(ga_transaction) AS ga_transaction,
    SUM(shp_order_net_sales) AS shp_order_net_sales,
    SUM(shp_discounts) AS shp_discounts,
    SUM(shp_gross_sales) AS shp_gross_sales,
    SUM(shp_net_sales) AS shp_net_sales,
    SUM(shp_returns) AS shp_returns,
    SUM(shp_shipping) AS shp_shipping,
    SUM(shp_sm_order_count) AS shp_sm_order_count,
    SUM(shp_tax) AS shp_tax,
    SUM(shp_total_sales) AS shp_total_sales, 
    SUM(shp_gross_sales_eur_currency_conversion) AS shp_gross_sales_eur_currency_conversion,
    SUM(shp_gross_sales_gbp_currency_conversion) AS shp_gross_sales_gbp_currency_conversion,
    SUM(shp_gross_sales_usd_currency_conversion) AS shp_gross_sales_usd_currency_conversion,
    SUM(shp_net_sales_eur_currency_conversion) AS shp_net_sales_eur_currency_conversion,
    SUM(shp_net_sales_gbp_currency_conversion) AS shp_net_sales_gbp_currency_conversion,
    SUM(shp_net_sales_usd_currency_conversion) AS shp_net_sales_usd_currency_conversion,
    SUM(shp_total_sales_eur_currency_conversion) AS shp_total_sales_eur_currency_conversion,
    SUM(shp_total_sales_gbp_currency_conversion) AS shp_total_sales_gbp_currency_conversion,
    SUM(shp_total_sales_usd_currency_conversion) AS shp_total_sales_usd_currency_conversion

FROM sessions_data_join
GROUP BY 1, 2, 3, 4, 5