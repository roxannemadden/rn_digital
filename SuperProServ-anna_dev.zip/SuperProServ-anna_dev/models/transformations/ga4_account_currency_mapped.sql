/* Adding the account mapping table to get the currency for the GA4 accounts */

WITH ga4_mapping_table AS (

    SELECT 
        Client_, 
        Google_Analytics_account_id, 
        Google_Analytics_4_id, 
        GA4_Default_Currency
    FROM {{ source('supermetrics', 'GS_account_mapping_currency') }}
    GROUP BY 
        Client_, 
        Google_Analytics_account_id, 
        Google_Analytics_4_id, 
        GA4_Default_Currency), 

ga4_data AS (SELECT * FROM {{ ref('ga4_source_unique_id') }}), 

/* Joining the account mapping table with the GA4 data to map the GA4 currency to each GA4 account */

ga4_data_currency_mapped AS (

    SELECT 
        ga4_date,
        ga4_profile_id,
        new_source,
        ga4_campaign_name,
        Client_,
        Google_Analytics_account_id,
        GA4_Default_Currency,
        purchaseRevenue,
        transactions, 
        ga4_eur_gbp_converted_revenue,
        ga4_eur_usd_converted_revenue, 
        ga4_gbp_eur_converted_revenue, 
        ga4_gbp_usd_converted_revenue, 
        ga4_usd_eur_converted_revenue, 
        ga4_usd_gbp_converted_revenue

        FROM ga4_data 
        INNER JOIN ga4_mapping_table 
            ON ga4_data.ga4_profile_id = ga4_mapping_table.Google_Analytics_4_id),
    
_surrogate_key AS (

SELECT *, 

    {{dbt_utils.surrogate_key(
        [
            'ga4_date',
            'ga4_profile_id',
            'new_source', 
            'ga4_campaign_name', 
            'Client_',
            'Google_Analytics_account_id', 
            'GA4_Default_Currency'
        ]
    )}} AS surrogate_key
    FROM ga4_data_currency_mapped)

SELECT *
FROM _surrogate_key





