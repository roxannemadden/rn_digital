
SELECT 
  --selecting the first transaction event based on the earliest date

  min(date) as transaction_date,
  order_name,
  shp_order_id,
  shop_id,
  shp_shop_name,
  shp_order_is_returning_customer,
  (order_name || shop_id) as unique_order_key,
  SUM(shp_net_sales) AS order_net_sales,
  SUM(shp_discounts) AS shp_discounts,
  SUM(shp_gross_sales) AS shp_gross_sales,
  SUM(shp_net_sales) AS shp_net_sales,
  SUM(shp_returns) AS shp_returns,
  SUM(shp_shipping) AS shp_shipping,
  SUM(shp_sm_order_count) AS shp_sm_order_count,
  SUM(shp_tax) AS shp_tax,
  SUM(shp_total_sales) AS shp_total_sales, 
  SUM(shp_gross_sales_eur_currency_conversion) AS shp_gross_sales_eur_currency_conversion,
  SUM(shp_gross_sales_gbp_currency_conversion) AS shp_gross_sales_gbp_currency_conversion,
  SUM(shp_gross_sales_usd_currency_conversion) AS shp_gross_sales_usd_currency_conversion,
  SUM(shp_net_sales_eur_currency_conversion) AS shp_net_sales_eur_currency_conversion,
  SUM(shp_net_sales_gbp_currency_conversion) AS shp_net_sales_gbp_currency_conversion,
  SUM(shp_net_sales_usd_currency_conversion) AS shp_net_sales_usd_currency_conversion,
  SUM(shp_total_sales_eur_currency_conversion) AS shp_total_sales_eur_currency_conversion,
  SUM(shp_total_sales_gbp_currency_conversion) AS shp_total_sales_gbp_currency_conversion,
  SUM(shp_total_sales_usd_currency_conversion) AS shp_total_sales_usd_currency_conversion    
  

  from {{ ref('stg_shopify') }}
GROUP BY 
    order_name, 
    shop_id, 
    shp_shop_name,
    shp_order_id,
    shp_order_is_returning_customer, 
    unique_order_key