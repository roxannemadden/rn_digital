with

    -- SOURCE TABLE
    -- where Secondary_profile_id NOT IN ('1672475754', '141180051')
    ga_data as (select * from {{ ref('ga_data_account_level_sessions_join') }}),

    external_sales_data as (select * from {{ ref('stg_external_sales_data') }}),

    _agg_ga_data as (
        select
            ga_date,
            ga_account as ga_account,
            ga_account_id,
            ga_source_medium as ga_new_source_medium,
            mapped_ga_accountname, 
            --TODO: replace md5 with dbt_utils.surrogate_key
            md5(ga_account_id || ga_date || ga_source_medium) as ga_unique_id,
            SUM(item_revenue) as ga_item_revenue,
            SUM(ga_session) as ga_session,
            SUM(ga_transaction_revenue) as ga_transaction_revenue,
            SUM(ga_transaction) as ga_transaction,
            SUM(shp_order_net_sales) as order_net_sales,
            SUM(shp_discounts) as shp_discounts,
            SUM(shp_gross_sales) as shp_gross_sales,
            SUM(shp_net_sales) as shp_net_sales,
            SUM(shp_returns) as shp_returns,
            SUM(shp_shipping) as shp_shipping,
            SUM(shp_sm_order_count) as shp_sm_order_count,
            SUM(shp_tax) as shp_tax,
            SUM(shp_total_sales) as shp_total_sales,
            SUM(shp_gross_sales_eur_currency_conversion) AS shp_gross_sales_eur_currency_conversion,
            SUM(shp_gross_sales_gbp_currency_conversion) AS shp_gross_sales_gbp_currency_conversion,
            SUM(shp_gross_sales_usd_currency_conversion) AS shp_gross_sales_usd_currency_conversion,
            SUM(shp_net_sales_eur_currency_conversion) AS shp_net_sales_eur_currency_conversion,
            SUM(shp_net_sales_gbp_currency_conversion) AS shp_net_sales_gbp_currency_conversion,
            SUM(shp_net_sales_usd_currency_conversion) AS shp_net_sales_usd_currency_conversion,
            SUM(shp_total_sales_eur_currency_conversion) AS shp_total_sales_eur_currency_conversion,
            SUM(shp_total_sales_gbp_currency_conversion) AS shp_total_sales_gbp_currency_conversion,
            SUM(shp_total_sales_usd_currency_conversion) AS shp_total_sales_usd_currency_conversion
        from ga_data
        group by 1, 2, 3, 4, 5, 6
    ),

    _agg_external_sales_data as (

        select

            ga_date,
            ga_account,
            ga_account_id,
            ga_new_source_medium,
            mapped_ga_accountname,
            ga_unique_id,
            SUM(ga_item_revenue) as ga_item_revenue,
            SUM(ga_session) as ga_session,
            SUM(ga_transaction_revenue) as ga_transaction_revenue,
            SUM(ga_transaction) as ga_transaction,
            SUM(order_net_sales) as order_net_sales,
            SUM(shp_discounts) as shp_discounts,
            SUM(shp_gross_sales) as shp_gross_sales,
            SUM(shp_net_sales) as shp_net_sales,
            SUM(shp_returns) as shp_returns,
            SUM(shp_shipping) as shp_shipping,
            SUM(shp_sm_order_count) as shp_sm_order_count,
            SUM(shp_tax) as shp_tax,
            SUM(shp_total_sales) as shp_total_sales,
            SUM(shp_gross_sales_eur_currency_conversion) AS shp_gross_sales_eur_currency_conversion,
            SUM(shp_gross_sales_gbp_currency_conversion) AS shp_gross_sales_gbp_currency_conversion,
            SUM(shp_gross_sales_usd_currency_conversion) AS shp_gross_sales_usd_currency_conversion,
            SUM(shp_net_sales_eur_currency_conversion) AS shp_net_sales_eur_currency_conversion,
            SUM(shp_net_sales_gbp_currency_conversion) AS shp_net_sales_gbp_currency_conversion,
            SUM(shp_net_sales_usd_currency_conversion) AS shp_net_sales_usd_currency_conversion,
            SUM(shp_total_sales_eur_currency_conversion) AS shp_total_sales_eur_currency_conversion,
            SUM(shp_total_sales_gbp_currency_conversion) AS shp_total_sales_gbp_currency_conversion,
            SUM(shp_total_sales_usd_currency_conversion) AS shp_total_sales_usd_currency_conversion            

        from external_sales_data
        group by 1, 2, 3, 4, 5, 6
    ),

    unioned_external_table as (

        select *
        from _agg_ga_data
        union all
        select *
        from _agg_external_sales_data
    )

select *
from unioned_external_table
order by ga_date desc 
