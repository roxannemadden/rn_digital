WITH 

stg_ga4 AS (
    select * from {{ ref('stg_ga4') }}
),

_source_aliasing AS (    
    SELECT 
    ga4_date, 
    ga4_profile, 
    ga4_profile_id, 
    ga4_source,
    ga4_campaign_name,
    SUM(purchaserevenue) AS purchaserevenue,
    SUM(transactions) AS transactions,
    SUM(ga4_eur_gbp_converted_revenue) AS ga4_eur_gbp_converted_revenue,
    SUM(ga4_eur_usd_converted_revenue) AS ga4_eur_usd_converted_revenue, 
    SUM(ga4_gbp_eur_converted_revenue) AS ga4_gbp_eur_converted_revenue, 
    SUM(ga4_gbp_usd_converted_revenue) AS ga4_gbp_usd_converted_revenue, 
    SUM(ga4_usd_eur_converted_revenue) AS ga4_usd_eur_converted_revenue, 
    SUM(ga4_usd_gbp_converted_revenue) AS ga4_usd_gbp_converted_revenue,

        CASE 
            WHEN ga4_source LIKE '%Social%' THEN 'facebook'
            WHEN ga4_source LIKE '%facebook%' THEN 'facebook'
            WHEN ga4_source LIKE '%bing%' THEN 'bing'
            WHEN ga4_source LIKE '%Criteo%' THEN 'criteo'
            WHEN ga4_source LIKE '%criteo%' THEN 'criteo'
            WHEN ga4_source LIKE '%google%' THEN 'google'
            ELSE ga4_source 
            END AS new_source

    FROM stg_ga4

    GROUP BY 
    ga4_date, 
    ga4_profile, 
    ga4_profile_id, 
    new_source, 
    ga4_source, 
    ga4_campaign_name

    ),

_surrogate_key AS (
    SELECT 
    ga4_profile,
    ga4_profile_id, 
    ga4_date, 
    new_source,
    ga4_campaign_name,
    purchaserevenue,
    transactions,
    ga4_eur_gbp_converted_revenue,
    ga4_eur_usd_converted_revenue, 
    ga4_gbp_eur_converted_revenue, 
    ga4_gbp_usd_converted_revenue, 
    ga4_usd_eur_converted_revenue, 
    ga4_usd_gbp_converted_revenue,

    {{dbt_utils.surrogate_key(
        [
            'ga4_date',
            'ga4_profile',
            'ga4_profile_id',
            'new_source', 
            'ga4_campaign_name'
        ]
    )}} AS surrogate_key

FROM _source_aliasing),

_agg AS (
    select 
    ga4_date,
    ga4_profile,
    ga4_profile_id,
    new_source,
    surrogate_key,
    ga4_campaign_name,
    sum(purchaseRevenue) AS purchaseRevenue,
    sum(transactions) AS transactions, 
    SUM(ga4_eur_gbp_converted_revenue) AS ga4_eur_gbp_converted_revenue,
    SUM(ga4_eur_usd_converted_revenue) AS ga4_eur_usd_converted_revenue, 
    SUM(ga4_gbp_eur_converted_revenue) AS ga4_gbp_eur_converted_revenue, 
    SUM(ga4_gbp_usd_converted_revenue) AS ga4_gbp_usd_converted_revenue, 
    SUM(ga4_usd_eur_converted_revenue) AS ga4_usd_eur_converted_revenue, 
    SUM(ga4_usd_gbp_converted_revenue) AS ga4_usd_gbp_converted_revenue

    from _surrogate_key
    group by 1, 2, 3, 4, 5, 6
)

SELECT 
* from _agg