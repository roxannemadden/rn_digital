with
    a as (
        select *
        from {{ ref("marketing_currency_conversion") }}
        where account_id not in ('1672475754', '141180051', '1442477537')
    ),

    b as (
        select
            * except (m_ga_account_name, google_analytics_account_id),
            case
                when contains_substr(campaign_name, 'BABYMEL')
                then 'Babymel'
                when contains_substr(campaign_name, 'STORKSAK')
                then 'Storksak'
                else null
            end as m_ga_account_name,
            case
                when contains_substr(campaign_name, 'BABYMEL')
                then '38321930'
                when contains_substr(campaign_name, 'STORKSAK')
                then '13291065'
                else null
            end as google_analytics_account_id
        from {{ ref("marketing_currency_conversion") }}
        where account_id in ('1672475754', '141180051', '1442477537')
    ),

    c as (

        select
    
    marketing_date, 
    marketing_source, 
    google_analytics_account_id, 
    account_id, 
    account_name, 
    m_ga_account_name, 
    campaign_name, 
    campaign_name_geo_mapping, 
    Ad_Platform_Default_Currency,
    Final_reporting_currency,  
    SUM(Cost) AS Cost,
    sum(cost_eur_conversion) AS cost_eur_conversion,
    sum(cost_gbp_conversion) AS cost_gbp_conversion, 
    sum(cost_usd_conversion) AS cost_usd_conversion

    from a 

    group by 

    marketing_date, 
    marketing_source, 
    google_analytics_account_id, 
    account_id, 
    account_name, 
    m_ga_account_name, 
    campaign_name, 
    campaign_name_geo_mapping, 
    Ad_Platform_Default_Currency,
    Final_reporting_currency

        union all

        select

    marketing_date, 
    marketing_source, 
    google_analytics_account_id, 
    account_id, 
    account_name, 
    m_ga_account_name, 
    campaign_name, 
    campaign_name_geo_mapping, 
    Ad_Platform_Default_Currency,
    Final_reporting_currency, 
    SUM(Cost) AS Cost,
    sum(cost_eur_conversion) AS cost_eur_conversion,
    sum(cost_gbp_conversion) AS cost_gbp_conversion, 
    sum(cost_usd_conversion) AS cost_usd_conversion
        
        from b

        group by 

    marketing_date, 
    marketing_source, 
    google_analytics_account_id, 
    account_id, 
    account_name, 
    m_ga_account_name, 
    campaign_name, 
    campaign_name_geo_mapping, 
    Ad_Platform_Default_Currency,
    Final_reporting_currency

    ), 


 account_exclusion_list AS 

(select * 

from c
    
where account_id not in (

'269229313',
'1274251662',
'10150853573838239',
'283567520',
'283567520',
'2022550384',
'141243117',
'6051451111',
'150312803',
'1064975631',
'473626757872904',
'4226749728',
'52474897',
'5236849129',
'382840006819157',
'11407983',
'5962099460',
'10153795192175162',
'3203937806',
'172103886568290',
'288848618156328',
'10209586954736916',
'141275750',
'1753790408',
'863099187623799',
'931561276911340',
'10153381431712304',
'6973623419',
'294254665154879',
'871178519913057',
'141257263',
'150442646',
'10158069978025467',
'448606256167979',
'10155862808136151',
'2241408091',
'1147884021969471',
'2620786669',
'3781280850',
'1137035113049394',
'5041629242',
'150464342',
'25172403',
'55455783',
'8579659419',
'8805395315',
'141222986',
'11472014',
'1442477537',
'7948581425',
'242592536343578',
'1854710084674168',
'328192144283651',
'1583373955',
'139031838',
'5440982781',
'171568740483673',
'603668167218147',
'1513543028839542'))


select
    *,
     {{ 
     dbt_utils.surrogate_key( 
     [
                "marketing_date",
                "marketing_source",
                "google_analytics_account_id",
                "account_id",
                "campaign_name", 
                "campaign_name_geo_mapping"
            ]
        )
    }} as surrogate_key

from account_exclusion_list
