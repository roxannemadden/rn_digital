-- -get a list of all campaign names currently present in the marketing data union
-- model
with
    distinct_campaign_name as (
        select distinct campaign_name from {{ ref("marketing_union_mapped_patched") }}
    ),

    -- -use the list of valid campaign names as a filter for the GA data to remove any
    -- entries that belong to earlier
    -- -versions of the campaigns (this step also excludes all entries that come from
    -- traffic sources outside of the marketing sources that we are pulling in like
    -- email or organic
    source_cleanup as (
        select
        * except (ga_source_medium),
    
            case
                when ga_source_medium like '%facebook / cpc%'
                then 'facebook'
                when ga_source_medium like '%facebook / paid%'
                then 'facebook'
                when ga_source_medium like '%fb / paid%'
                then 'facebook'
                when ga_source_medium like '%bing / cpc%'
                then 'bing'
                when ga_source_medium like '%google / cpc%'
                then 'google'
                when ga_source_medium like '%Criteo%'
                then 'criteo'
                when ga_source_medium like '%criteo%'
                then 'criteo'
                when ga_source_medium like '%tiktok / (not set)%'
                then 'tiktok'
                when ga_source_medium like '%ads.pinterest.com%'
                then 'pinterest'
                when ga_source_medium like '%stackadapt%'
                then 'stackadapt'
                when ga_source_medium like '%snapchat / cpc	%'
                then 'snapchat'

                else ga_source_medium
                end as ga_source_medium,
            
        from {{ ref("stg_ga_sessions_by_campaign") }}
        where
            ga_campaign in (select campaign_name from distinct_campaign_name)

            -- -get also the entries where campaign is not set at all back in
          or ga_campaign IS NOT NULL  
    ), 

    gs_ga_mapping as (
        select
            client_ as mapped_ga_accountname,
            safe_cast(google_analytics_account_id as string) as mapped_ga_id
        from {{ source('supermetrics', 'GS_account_mapping') }}
        group by client_, mapped_ga_id
    ),


account_name_mapping as 

        (select
            source_cleanup.*,
            gs_ga_mapping.mapped_ga_accountname
        from source_cleanup
        left join
            gs_ga_mapping
            on gs_ga_mapping.mapped_ga_id = source_cleanup.ga_account_id
        )


select * except (ga_account) from account_name_mapping



