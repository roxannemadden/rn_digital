with

    -- SOURCE TABLES
    ga_transaction_data as (select * from {{ ref('ga_campaign_cleaned') }}),

    shp_data_mapped_ga_account as (
        select * from {{ ref('shp_ga_mapping') }}
    ),

    gs_ga_mapping as (
        select
            client_ as mapped_ga_accountname,
            safe_cast(google_analytics_account_id as string) as mapped_ga_id
        from {{ source('supermetrics', 'GS_account_mapping') }}
        group by client_, mapped_ga_id
    ),


    joined_table as (
        select
            ga_transaction_data.*,
            shp_data_mapped_ga_account.*,
            gs_ga_mapping.mapped_ga_accountname
        from ga_transaction_data
        left join
            gs_ga_mapping
            on gs_ga_mapping.mapped_ga_id = ga_transaction_data.ga_account_id
        left join
            shp_data_mapped_ga_account
            on ga_transaction_data.unique_transaction_id
            = shp_data_mapped_ga_account.unique_shp_transaction_id
    )


select *
from joined_table
