/* This code outputs the duplicates of a failing uniqueness test for troubleshooting quickly */

/* variable targetModel controls which model is being tested. Enter the ref string here.     */
/* variable uniqueKey controls the name of the column that should be unique.                 */
{% set targetModel = 'marketing_union_mapped_patched' %}
{% set uniqueKey = 'surrogate_key' %}
/*-------------------------------------------------------------------------------------------*/

with dbt_test__target as (

  select *
  from {{ref(targetModel)}}
  where {{uniqueKey}} is not null

),

duplicates as (select
    {{uniqueKey}},
    count(*) as n_records

from dbt_test__target
group by {{uniqueKey}}
having count(*) > 1)

select * from dbt_test__target where {{uniqueKey}} in (select distinct {{uniqueKey}} from duplicates)
order by {{uniqueKey}}