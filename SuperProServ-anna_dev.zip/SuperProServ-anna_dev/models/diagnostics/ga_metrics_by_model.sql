{{ config(materialized="table") }}

SELECT 
'0_raw_ga_data' as model,
    date as ga_date,
    account as ga_account,
    source_medium as ga_source_medium,
    campaign as ga_campaign,

    sum (item_revenue) as ga_item_revenue,
    sum (session) as ga_session,
    sum (transaction_revenue) as ga_transaction_revenue,
    sum (transaction) as ga_transaction

from {{ source("supermetrics", "GA_CAMPAIGN_TRANSACTION_ID_SOURCE_M_*") }}

GROUP BY ga_date, ga_account, ga_source_medium, ga_campaign

UNION ALL

SELECT 
'1_ga_data_stg' as model,
    ga_date,
    ga_account,
    ga_source_medium,
    ga_campaign,

    sum (ga_item_revenue) as ga_item_revenue,
    sum (ga_session) as ga_session,
    sum (ga_transaction_revenue) as ga_transaction_revenue,
    sum (ga_transaction) as ga_transaction

FROM {{ ref("stg_ga_campaign_transaction") }}  

GROUP BY ga_date, ga_account, ga_source_medium, ga_campaign


UNION ALL  

SELECT 
'2_ga_campaign_cleaned' as model,
    ga_date,
    ga_account,
    ga_source_medium,
    ga_campaign,

    sum (ga_item_revenue) as ga_item_revenue,
    sum (ga_session) as ga_session,
    sum (ga_transaction_revenue) as ga_transaction_revenue,
    sum (ga_transaction) as ga_transaction

FROM {{ ref("ga_campaign_cleaned") }}  

GROUP BY ga_date, ga_account, ga_source_medium, ga_campaign

UNION ALL

SELECT 
'3_ga_shp_transaction_join' as model,
    ga_date,
    ga_account,
    ga_source_medium,
    ga_campaign,

    sum (ga_item_revenue) as ga_item_revenue,
    sum (ga_session) as ga_session,
    sum (ga_transaction_revenue) as ga_transaction_revenue,
    sum (ga_transaction) as ga_transaction

FROM {{ ref("ga_shp_transaction_join") }}  

GROUP BY ga_date, ga_account, ga_source_medium, ga_campaign 

UNION ALL 

SELECT

'4_shp_campaign_join' as model,
    ga_date,
    ga_account,
    ga_source_medium,
    ga_campaign,

    sum (item_revenue) as ga_item_revenue,
    sum (ga_session) as ga_session,
    sum (ga_transaction_revenue) as ga_transaction_revenue,
    sum (ga_transaction) as ga_transaction

FROM {{ ref("ga_shp_campaign_join") }}  

GROUP BY ga_date, ga_account, ga_source_medium, ga_campaign 

UNION ALL 


SELECT

'5_marketing_union_ga_shp_campaign_join' as model,
    master_date,
    master_accountname,
    master_source_medium,
    master_campaign_name,

    sum (ga_item_revenue) as ga_item_revenue,
    sum (ga_session) as ga_session,
    sum (ga_transaction_revenue) as ga_transaction_revenue,
    sum (ga_orders) as ga_transaction

FROM {{ ref("marketing_union_ga_shp_campaign_join") }}  

GROUP BY  master_date, master_accountname, master_source_medium, master_campaign_name