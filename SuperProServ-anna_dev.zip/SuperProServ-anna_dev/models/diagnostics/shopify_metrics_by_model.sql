{{ config(materialized="table") }}

SELECT 
'0_raw_shp_data' as model,
    sum(net_sales) as shp_net_sales,
    sum(total_sales) as shp_total_sales,
    sum(gross_sales) as shp_gross_sales,
    sum(discounts) as shp_discounts,
    sum(returns) as shp_returns,
    sum(shipping) as shp_shipping,
    sum(sm_order_count) as shp_orders, 
    sum(tax) as shp_tax,
    
    date as shp_date,  
    shop_name as account_name

FROM {{ source('supermetrics', 'SHP_SHOPIFY_SALES_DATA_*') }} 

GROUP BY shp_date, account_name 

UNION ALL

SELECT 
'1_stg_shp_data' as model,
    sum(shp_net_sales) as shp_net_sales,
    sum(shp_total_sales) as shp_total_sales,
    sum(shp_gross_sales) as shp_gross_sales,
    sum(shp_discounts) as shp_discounts,
    sum(shp_returns) as shp_returns,
    sum(shp_shipping) as shp_shipping,
    sum(shp_sm_order_count) as shp_orders, 
    sum(shp_tax) as shp_tax,

    date as shp_date,  
    shp_shop_name as account_name

FROM {{ ref("stg_shopify") }}  

GROUP BY shp_date, account_name 

UNION ALL  

SELECT 
'2_shopify_order_id_aggregation' as model,
    sum(shp_net_sales) as shp_net_sales,
    sum(shp_total_sales) as shp_total_sales,
    sum(shp_gross_sales) as shp_gross_sales,
    sum(shp_discounts) as shp_discounts,
    sum(shp_returns) as shp_returns,
    sum(shp_shipping) as shp_shipping,
    sum(shp_sm_order_count) as shp_orders, 
    sum(shp_tax) as shp_tax,

    transaction_date as shp_date,  
    shp_shop_name as account_name

FROM {{ ref("shp_order_id_aggregation") }}  

GROUP BY shp_date, account_name 

UNION ALL

SELECT 

'3_shp_new_returning_revenue_order_name' as model,
    sum(shp_net_sales) as shp_net_sales,
    sum(shp_total_sales) as shp_total_sales,
    sum(shp_gross_sales) as shp_gross_sales,
    sum(shp_discounts) as shp_discounts,
    sum(shp_returns) as shp_returns,
    sum(shp_shipping) as shp_shipping,
    sum(shp_sm_order_count) as shp_orders, 
    sum(shp_tax) as shp_tax,

    date as shp_date,  
    shp_shop_name as account_name

FROM {{ ref("shp_new_returning_revenue_order_name") }}  

GROUP BY shp_date, account_name 

UNION ALL 

SELECT

'4_shp_ga_mapping' as model,
    sum(shp_net_sales) as shp_net_sales,
    sum(shp_total_sales) as shp_total_sales,
    sum(shp_gross_sales) as shp_gross_sales,
    sum(shp_discounts) as shp_discounts,
    sum(shp_returns) as shp_returns,
    sum(shp_shipping) as shp_shipping,
    sum(shp_sm_order_count) as shp_orders, 
    sum(shp_tax) as shp_tax,

    transaction_date as shp_date,  
    shp_shop_name as account_name

FROM {{ ref("shp_ga_mapping") }}  

GROUP BY shp_date, account_name

UNION ALL 

SELECT

'5_ga_shp_transaction_join' as model,
    sum(shp_net_sales) as shp_net_sales,
    sum(shp_total_sales) as shp_total_sales,
    sum(shp_gross_sales) as shp_gross_sales,
    sum(shp_discounts) as shp_discounts,
    sum(shp_returns) as shp_returns,
    sum(shp_shipping) as shp_shipping,
    sum(shp_sm_order_count) as shp_orders, 
    sum(shp_tax) as shp_tax,

    transaction_date as shp_date,  
    mapped_ga_accountname as account_name

FROM {{ ref("ga_shp_transaction_join") }}  

GROUP BY shp_date, account_name

UNION ALL 

SELECT

'6_ga_shp_campaign_join' as model,
    sum(shp_net_sales) as shp_net_sales,
    sum(shp_total_sales) as shp_total_sales,
    sum(shp_gross_sales) as shp_gross_sales,
    sum(shp_discounts) as shp_discounts,
    sum(shp_returns) as shp_returns,
    sum(shp_shipping) as shp_shipping,
    sum(shp_sm_order_count) as shp_orders, 
    sum(shp_tax) as shp_tax,

    ga_date as shp_date,  
    mapped_ga_accountname as account_name

FROM {{ ref("ga_shp_campaign_join") }}  

GROUP BY shp_date, account_name

UNION ALL

SELECT

'7_marketing_union_ga_shp_campaign_join' as model,
    sum(shopify_order_net_sales) as shp_net_sales,
    sum(shopify_total_sales) as shp_total_sales,
    sum(shopify_gross_sales) as shp_gross_sales,
    sum(shopify_discounts) as shp_discounts,
    sum(shopify_returns) as shp_returns,
    sum(shopify_shipping_costs) as shp_shipping,
    CAST (null as int64) as shp_orders, 
    sum(shopify_tax) as shp_tax,

    master_date as shp_date,  
    master_accountname as account_name

FROM {{ ref("marketing_union_ga_shp_campaign_join") }}  

GROUP BY shp_date, account_name