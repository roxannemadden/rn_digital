{{ config(materialized="table") }}

SELECT 
'0_raw_data' as model,
    sum(platforms_cost) as platforms_cost, 
    source_platform, 
    date,  
    account_name,
    campaign_name

FROM 
( 
  select 
    sum(cost) as platforms_cost,
    data_source_name as source_platform, 
    date,
    advertiser_name as account_name, 
    campaign_name as campaign_name

    from {{ source('supermetrics', 'CRI_COST_DATA_CRI_*') }} 

    GROUP BY source_platform, date, account_name, campaign_name

  UNION ALL
  select 
    sum (spend) as platforms_cost, 
    data_source_name as source_platform, 
    date,
    account_name as account_name, 
    campaign_name as campaign_name
  
  from {{ source('supermetrics', 'BINGADS_KEY_METRICS_*') }}  

  GROUP BY source_platform, date, account_name, campaign_name

  UNION ALL 
  select 
    sum (cost) as platforms_cost, 
    data_source_name as source_platform, 
    date,
    profile as account_name, 
    campaign_name as campaign_name
 
  from {{ source("supermetrics", "FBADS_COST_DATA_*") }}

  GROUP BY source_platform, date, account_name, campaign_name

UNION ALL 
  select 
    sum (cost) as platforms_cost, 
    data_source_name as source_platform, 
    date,
    account_name as account_name, 
    campaign_name as campaign_name
 
  from {{ source("supermetrics", "GOOGLEADS_CAMPAIGN_LEVEL_COST_*") }}

  GROUP BY source_platform, date, account_name, campaign_name

UNION ALL 
  select 
    sum (cost) as platforms_cost, 
    dataSourceName as source_platform, 
    date,
    advertiser_name as account_name,
    campaign_name as campaign_name
 
  from {{ source("supermetrics", "TIK_KEY_METRICS_TIKTOK_*") }}

  GROUP BY source_platform, date, account_name, campaign_name

UNION ALL 
  select 
    sum (cost) as platforms_cost, 
    data_source_name as source_platform, 
    date,
    account_name as account_name,
    campaign_name as campaign_name
 
  from {{ source("supermetrics", "SCM_SNAPCHAT_ADS_COST_DATA_*") }}

  GROUP BY source_platform, date, account_name, campaign_name

UNION ALL 
  select 
    sum (cost) as platforms_cost, 
    data_source_name as source_platform, 
    date,
    account_name as account_name,
    campaign_name as campaign_name
 
  from {{ source("supermetrics", "PIA_PIA_KEY_METRICS_*") }}

  GROUP BY source_platform, date, account_name, campaign_name

UNION ALL 

  select 
    sum (cost) as platforms_cost, 
    dataSourceName as source_platform, 
    date,
    advertiser as account_name,
    campaign as campaign_name
 
  from {{ source("supermetrics", "STAC_SA_KEY_METRICS_*") }}

  GROUP BY source_platform, date, account_name, campaign_name

)

GROUP BY source_platform, date, account_name, campaign_name


UNION ALL

SELECT

'1_staging_models' as model,
    sum(platforms_cost) as platforms_cost, 
    source_platform, 
    date,  
    account_name,
    campaign_name as campaign_name

FROM 
( 
  select 
    sum(criteo_spend) as platforms_cost,
    criteo_data_source_name as source_platform, 
    criteo_date as date,
    criteo_account_name as account_name,
    criteo_campaign_name as campaign_name

   from {{ ref("stg_criteo") }}  

   GROUP BY source_platform, date, account_name, campaign_name

  UNION ALL

  select 
    sum (bing_spend) as platforms_cost, 
    bing_data_source_name as source_platform, 
    bing_date as date,
    bing_account_name as account_name, 
    bing_campaign_name as campaign_name
  
  from {{ ref("stg_bing_ads") }}  

  GROUP BY source_platform, date, account_name, campaign_name


  UNION ALL 

  select 
    sum (facebook_spend) as platforms_cost, 
    facebook_data_source_name as source_platform, 
    facebook_date as date,
    facebook_account_name as account_name,
    facebook_campaign_name as campaign_name
 
    from {{ ref("stg_facebook_ads") }}  

    GROUP BY source_platform, date, account_name, campaign_name


UNION ALL 
  select 
    sum (google_ads_cost) as platforms_cost, 
    google_ads_data_source_name as source_platform, 
    google_ads_date as date,
    google_ads_account_name as account_name,
    google_ads_campaign_name as campaign_name
 
    from {{ ref("stg_google_ads") }}  

    GROUP BY source_platform, date, account_name, campaign_name

UNION ALL 

  select 
    sum (tiktok_spend) as platforms_cost, 
    tiktok_data_source_name as source_platform, 
    tiktok_date as date,
    tiktok_account_name as account_name, 
    tiktok_campaign_name as campaign_name
 
  from {{ ref("stg_tiktok") }}

  GROUP BY source_platform, date, account_name, campaign_name

UNION ALL 

  select 
    sum (snapchat_spend) as platforms_cost, 
    snapchat_data_source_name as source_platform, 
    snapchat_date as date,
    snapchat_account_name as account_name,
    snapchat_campaign_name as campaign_name
 
  from {{ ref("stg_snapchat") }}

  GROUP BY source_platform, date, account_name, campaign_name

UNION ALL 

  select 
    sum (pinterest_spend) as platforms_cost, 
    pinterest_data_source_name as source_platform, 
    pinterest_date as date,
    pinterest_account_name as account_name,
    pinterest_campaign_name as campaign_name
 
  from {{ ref("stg_pinterest") }}

  GROUP BY source_platform, date, account_name, campaign_name

UNION ALL 

  select 
    sum (stackadapt_spend) as platforms_cost, 
    stackadapt_data_source_name as source_platform, 
    stackadapt_date as date,
    stackadapt_account_name as account_name,
    stackadapt_campaign_name as campaign_name
 
  from {{ ref("stg_stackadapt") }}

  GROUP BY source_platform, date, account_name, campaign_name

)

GROUP BY source_platform, date, account_name, campaign_name

union all

  select 
'2_new_union_marketing_data' as model,
    sum(cost) as platforms_cost, 
    data_source_name as source_platform, 
    date,  
    account_name,
    campaign_name as campaign_name
  from {{ ref("new_union_marketing_data") }}

GROUP BY source_platform, date, account_name, campaign_name

union all

  select
'3_ga_campaign_marketing_union_unique_id' as model,
    sum(cost) as platforms_cost, 
    marketing_source as source_platform, 
    date,  
    account_name,
    campaign_name as campaign_name
  from {{ ref("ga_campaign_marketing_union_unique_id") }}

GROUP BY source_platform, date, account_name, campaign_name

union all 

  select
'4_marketing_currency_conversion' as model,
    sum(Cost) as platforms_cost, 
    marketing_source as source_platform, 
    marketing_date as date,  
    account_name,
    campaign_name
  from {{ ref("marketing_currency_conversion") }}

GROUP BY source_platform, date, account_name, campaign_name
  
union all

  select 
'5_marketing_union_mapped_patched' as model,
    sum(cost) as platforms_cost, 
    marketing_source as source_platform, 
    marketing_date as date,  
    account_name,
    campaign_name as campaign_name
  from {{ ref("marketing_union_mapped_patched") }}

GROUP BY source_platform, date, account_name, campaign_name

union all

  select 
'6_marketing_union_ga_shp_campaign_join' as model,
    sum(m_cost) as platforms_cost, 
    new_source_grouping as source_platform, 
    master_date as date,  
    master_accountname as account_name,
    master_campaign_name as campaign_name
  from {{ ref("marketing_union_ga_shp_campaign_join") }}

GROUP BY source_platform, date, account_name, campaign_name
