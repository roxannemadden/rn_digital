{{ config(materialized="table") }}

SELECT

'1_ga4_source' as model,

    sum(purchaserevenue) as purchase_revenue,
    sum(transactions) as transactions,
    date,
    propertyname as ga4_profile

FROM {{ source("supermetrics", "GAWA_UPDATED_GA4_BY_VIEW_*") }}

GROUP BY date, propertyname 

UNION ALL

SELECT

'2_ga4_stg' as model,

    sum(purchaserevenue) as purchase_revenue,
    sum(transactions) as transactions,
    ga4_date as date,
    ga4_profile

FROM {{ ref('stg_ga4') }} 

GROUP BY date, ga4_profile

UNION ALL 

SELECT

'3_new_ga4_marketing_data_join' as model,

    sum(purchase_revenue) as purchase_revenue,
    sum(transactions) as transactions,
    master_date,
    master_account_name as ga4_profile

FROM {{ ref('new_ga4_marketing_data_join') }} 

GROUP BY master_date, master_account_name